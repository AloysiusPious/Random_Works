  #! /usr/bin/ksh
# #################################################################################
#
# Script  : CertChainCreate_was.sh
#
# Description:
# To create new certificate chain and with 5110 days validity and 
# replace with existing default certificate
##################################################################################
#History
# 1.0 initial script created by Aloysius Pious
#
###################################################################################
Version="1.0"
############### ###################################################################
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}
export DISPLAY=""
DATE=`date "+%d%m%Y"`
Present_Dir=`pwd`
WAS_INSTALL_ROOT=/usr/IBM
WAS_INST_HOME=${WAS_INSTALL_ROOT}/WebSphere/AppServer
PROFILE_HOME=${WAS_INST_HOME}/profiles/AppSrv01
if [ ! -d ${PROFILE_HOME} ] ; then
   log_it "Failed... ${PROFILE_HOME} not found"
exit 0
fi

> ${tmpFile}
if [ $? -ne 0 ] ; then
   log_it "Error: Unable to create ${tmpFile}"
   exit 98
fi

######################################################################################
${PROFILE_HOME}/bin/wsadmin.sh -lang jython -f ${Present_Dir}/CertChainCreate_was.py
log_it "OK"
log_it "Restarting the WebSphere process..."
${PROFILE_HOME}/bin/stopServer.sh server1
${PROFILE_HOME}/bin/startServer.sh server1
log_it "OK"
