#!/usr/bin/ksh
# ########################################################################
# Name:  ihs_ops.sh
#
# Description:
# To append the IHS arihive log script to the crontab and to place the scripts in required location
############################################################################
SW_REP=/mnt/WAS/WAS_7
mkdir -p /usr/perlscripts/httplogarchive/
cd /usr/perlscripts/httplogarchive/
cp ${SW_REP}/utilities/bin/ibhttp_log_archive.pl .
chmod 755 *
echo "# IHS LOG Archive" >> /var/spool/cron/crontabs/root
echo "00 23 * * * /usr/perlscripts/httplogarchive/ibhttp_log_archive.pl 1>/dev/null 2>/dev/null" >> /var/spool/cron/crontabs/root
PID=`ps -ef | grep -v grep | grep cron | awk '{print $2}'`
kill -9 $PID
