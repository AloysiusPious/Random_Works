############################was_post_install.py########################################
import sys
import socket
#######################Define the Variable#############################################
cellName = AdminControl.getCell( )
nodeName = AdminControl.getNode( )
hostName = socket.gethostname( )
#######################################################################################
print cellName
print nodeName
print hostName
test1=AdminTask.listPersonalCertificates(['-keyStoreName NodeDefaultKeyStore -keyStoreScope (cell):'+cellName+':(node):'+nodeName] )  
print test1
print '################################################################################################'
AdminTask.createChainedCertificate(['-keyStoreName NodeDefaultKeyStore -keyStoreScope (cell):'+cellName+':(node):'+nodeName+' -certificateAlias '+hostName+'-ssl -rootCertificateAlias root -certificateSize 1024 -certificateCommonName '+hostName+' -certificateOrganization AlRajhi -certificateOrganizationalUnit TSD -certificateLocality -certificateState -certificateZip -certificateCountry SA -certificateValidDays 5110 '])  
############################################Run replace command####################################
AdminTask.replaceCertificate(['-certificateAlias default -replacementCertificateAlias '+hostName+'-ssl -deleteOldCert true -deleteOldSigners true -keyStoreName NodeDefaultKeyStore -keyStoreScope (cell):'+cellName+':(node):'+nodeName+''])  
#######################################List new certificate############################
test2=AdminTask.listPersonalCertificates(['-keyStoreName NodeDefaultKeyStore -keyStoreScope (cell):'+cellName+':(node):'+nodeName] )
print test2
#############################################SaveConfig change#####################
AdminConfig.save( )
