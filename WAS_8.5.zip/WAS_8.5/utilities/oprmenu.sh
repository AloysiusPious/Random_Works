#! /usr/bin/ksh
# #################################################################################
#
# Script  : oprmenu.sh
#      Prepare Operator Menu for WAS7 
##################################################################################
#History
# 1.0 initial script created by Aloysius Pious
###################################################################################
Version="1.1"
############### ###################################################################
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}
export DISPLAY=""
DATE=`date "+%d%m%Y"`
Present_Dir=`pwd`
installdir=/backup/installation
tmpDir=${installdir}/was/working
WAS_INSTALL_ROOT=/usr/IBM
WAS_INST_HOME=${WAS_INSTALL_ROOT}/WebSphere/AppServer
PROF_HOME=${WAS_INST_HOME}/profiles
OPR_MENU_FILE=/home/sys1/clearlogs.ksh
ls -1 ${PROF_HOME} > ${tmpDir}/profile.txt
log_it " Preparing Clearlogs.sh file..."
##########################################################################
echo "#!/bin/ksh" > ${OPR_MENU_FILE}
echo "# Script to Restart Websphere/IBM HTTP Server and the WebSphere logs" >> ${OPR_MENU_FILE}
echo "#" >> ${OPR_MENU_FILE}
echo "# NB !!!!!!!!!!!! Remember to stop WebSphere if you want to delete" >> ${OPR_MENU_FILE}
echo "# all the logs" >> ${OPR_MENU_FILE}
echo "############################################################################" >> ${OPR_MENU_FILE}
echo "#" >> ${OPR_MENU_FILE}
echo "quit=n" >> ${OPR_MENU_FILE}
echo "clear" >> ${OPR_MENU_FILE}
echo "while test \"\$quit\" = \"n\"" >> ${OPR_MENU_FILE}
echo "do" >> ${OPR_MENU_FILE}
####################Writing Operator menu epecific to each profile#######################
echo "\t\t clear ">> ${OPR_MENU_FILE}
echo "\t\t echo \"==================================\" ">> ${OPR_MENU_FILE}
echo "\t\t echo \"               Menu               \" ">> ${OPR_MENU_FILE}
echo "\t\t echo \"==================================\" ">> ${OPR_MENU_FILE}
integer j
j=1
for i in `cat ${tmpDir}/profile.txt`
do
echo "\t\t echo \" $j . Stop $i Websphere Node \" ">> ${OPR_MENU_FILE}
j=j+1
done
echo "\t\t echo \" ================================== \" ">> ${OPR_MENU_FILE}
echo "\t\t echo \" $j . Stop IHS Admin Server \" ">> ${OPR_MENU_FILE}
j=j+1
echo "\t\t echo \" $j . Stop IHS WebServer \" ">> ${OPR_MENU_FILE} 
echo "\t\t echo \" ================================== \" ">> ${OPR_MENU_FILE}
j=j+1
for i in `cat ${tmpDir}/profile.txt`
do
echo "\t\t echo \" $j . Start $i Websphere Node \" ">> ${OPR_MENU_FILE}
j=j+1
done
echo "\t\t echo \" ================================== \" ">> ${OPR_MENU_FILE}
echo "\t\t echo \" $j . Start IHS Admin Server \" ">> ${OPR_MENU_FILE}
j=j+1
echo "\t\t echo \" $j . Start IHS WebServer \" ">> ${OPR_MENU_FILE}
echo "\t\t echo \" ================================== \" ">> ${OPR_MENU_FILE}
j=j+1
for i in `cat ${tmpDir}/profile.txt`
do
echo "\t\t echo \" $j . Kill $i Websphere Process \" ">> ${OPR_MENU_FILE}
j=j+1
done
echo "\t\t echo \" ================================== \" ">> ${OPR_MENU_FILE}
echo "\t\t echo \" $j . Check For the Websphere Java process \" ">> ${OPR_MENU_FILE}
j=j+1
echo "\t\t echo \" $j . Check for HTTP server processes \" ">> ${OPR_MENU_FILE}
echo "\t\t echo \" ================================== \" ">> ${OPR_MENU_FILE}
j=j+1
echo "\t\t echo \" $j . Quit \" ">> ${OPR_MENU_FILE}
echo "\t\t echo" >> ${OPR_MENU_FILE}
####################Check Later
echo "\t\t echo -n \" Enter Choice: .\b \" ">> ${OPR_MENU_FILE}
echo "\t\t read choice ">> ${OPR_MENU_FILE}
echo "\t\t case \$choice in ">> ${OPR_MENU_FILE}
j=1
for i in `cat ${tmpDir}/profile.txt`
do
echo "\t\t $j) /usr/IBM/WebSphere/AppServer/profiles/$i/bin/stopServer.sh server1 | more;; ">> ${OPR_MENU_FILE}
j=j+1
done
echo "\t\t $j) /usr/IBM/HTTPServer/bin/adminctl stop | more;; ">> ${OPR_MENU_FILE}
j=j+1
echo "\t\t $j) /usr/IBM/HTTPServer/bin/apachectl stop | more;; ">> ${OPR_MENU_FILE}
j=j+1
for i in `cat ${tmpDir}/profile.txt`
do
echo "\t\t $j) /usr/IBM/WebSphere/AppServer/profiles/$i/bin/startServer.sh server1 | more;; ">> ${OPR_MENU_FILE}
j=j+1
done
echo "\t\t $j) /usr/IBM/HTTPServer/bin/adminctl start | more;; ">> ${OPR_MENU_FILE}
j=j+1
echo "\t\t $j) /usr/IBM/HTTPServer/bin/apachectl start | more;; ">> ${OPR_MENU_FILE}
j=j+1
for i in `cat ${tmpDir}/profile.txt`
do
echo "\t\t $j) kill -9 \`< /usr/IBM/WebSphere/AppServer/profiles/$i/logs/server1/server1.pid \`;; ">> ${OPR_MENU_FILE}
j=j+1
done

echo "\t\t $j) ps -ef | grep java | more;; ">> ${OPR_MENU_FILE}
j=j+1
echo "\t\t $j) ps -ef | grep httpd | more;; ">> ${OPR_MENU_FILE}
j=j+1
echo "\t\t $j) quit=y;; ">> ${OPR_MENU_FILE}
j=j+1
echo "\t\t *) echo \"Invalid choice \\$j\\$j \" ">> ${OPR_MENU_FILE}
echo "\t\t sleep 1 ">> ${OPR_MENU_FILE}
echo "\t\t esac ">> ${OPR_MENU_FILE}
echo "\t\t done ">> ${OPR_MENU_FILE}
chmod 755 ${OPR_MENU_FILE}
rm ${tmpDir}/profile.txt
log_it " Done..."
