#!/usr/bin/perl -w
###############################################################################
#
# Name          : ibhttp_log_archive.pl
#
# Desc          : This script archives logs associated with HTTP access and Error
#
# Parameters    : Log Category - [HTTP Logs]
#
# Author        : A.Rana [Al Rajhi Bank]
#               : Modified by Ibrahim for usage for new E-Tadawul
#
# Date          : 2004/11/20
#
# Notes         : The log files adhere to the following format :
#                 <logcategory_log.yyyy-mm-dd
#                 eg. access_log.2002-12-23
#
# Modifications : Ibrahim Sheriff 2007/05/28
#                 Initial creation
#               : Neill Rynders - Date -2 modifications added for archival 2007/07/02
#
#
#
###############################################################################

use strict;
package Echo;
use File::Copy;
#use Time::localtime;
use File::Path;
use POSIX qw(mktime strftime);

my @now = localtime();  ## get the current [sec, min, ...] values
my @past = @now;
my $date_to_archive;

my $file_name;
my $log_dir;
my $work_dir;
my @values;
my @date;
my $tm = localtime;
my $monyear;
my $log_prefix;
my $tmplogs;
my $access_logs;
my $error_logs;

# REMEMBER : Set the correct directory name below for the $log_dir

$work_dir = "/usr/IBM/HTTPServer/logs";
$log_dir = "/archive/http";

$access_logs = "yes";
$error_logs  = "yes";

$past[3] -= 2; ## same time, 2 days ago
$date_to_archive = strftime("%Y-%m-%d", @past);

chdir ("$work_dir") || die "Can't change to $work_dir !";


# Set the tmp filename string to search on
if ($access_logs eq "yes")
        {
                $tmplogs = "access_log." . $date_to_archive
        }

if ($access_logs eq "yes")
        {
for $file_name (glob("$tmplogs"))
{

  # The time stamp may be different on each file, so we have to
  # place this code in the loop]

  #print "\n $file_name";

  @values = split('\.',$file_name);
  @date = split("-",$values[1]);
  $monyear = $date[1] . $date[0];
  #print "\n $monyear";

  if (!(-e "$log_dir/$monyear"))
  {
    mkpath("$log_dir/$monyear",1,0711);
  }

  #print "\n Attempting to copy $work_dir/$file_name";
  copy("$work_dir/$file_name","$log_dir/$monyear") || die "Can't copy file $file_name";

 #print "\n Attempting to zip $log_dir/$monyear/$file_name";
  system ("gzip $log_dir/$monyear/$file_name");


  if (-e "$log_dir/$monyear/$file_name.gz")
  {
    #print "\n Ok, Attempting to delete $work_dir/$file_name";
    unlink ("$work_dir/$file_name") || die "Can't delete file $work_dir/$file_name";
    #print ("$work_dir/$file_name");
  }

 }
}

if ($error_logs eq "yes")
        {
                $tmplogs = "error_log." . $date_to_archive
        }

if ($error_logs eq "yes")
        {
for $file_name (glob("$tmplogs"))
{

  # The time stamp may be different on each file, so we have to
  # place this code in the loop

  @values = split('\.',$file_name);
  @date = split("-",$values[1]);
  $monyear = $date[1] . $date[0];

  if (!(-e "$log_dir/$monyear"))
  {
    mkpath("$log_dir/$monyear",1,0711);
  }

  #print "Attempting to copy $work_dir/$log_cat/$file_name";
  copy("$work_dir/$file_name","$log_dir/$monyear") || die "Can't copy file $file_name";

  #print "Attempting to zip $log_dir/$monyear/$log_cat/$file_name";
  system ("gzip $log_dir/$monyear/$file_name");


  if (-e "$log_dir/$monyear/$file_name.gz")
  {
    #print "\n Ok, Attempting to delete $work_dir/$file_name";
    unlink ("$work_dir/$file_name") || die "Can't delete file $work_dir/$file_name";
    #print ("$work_dir/$file_name");
  }

 }
}

