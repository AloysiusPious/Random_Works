#!/bin/ksh
prof_name=AppSrv03
find_str=/usr/IBM/WebSphere/AppServer/profiles/${prof_name}/config
log_file="/usr/perlscripts/monitor/${prof_name}_check.txt"
> $log_file
find_proc=`ps -ef | grep ${find_str} | grep -v grep | wc -l`
if [ ${find_proc} -lt 1 ]
then
    echo "not found" > $log_file
fi
