#!/usr/bin/ksh
# ########################################################################
# Name:  ihs_conf.sh
#
# Description:
# To add the entry for HTTP server Hadening entres also it will edit the 
# admin.conf file and make the http server ready to start
############################################################
DATE=`date "+%d%m%Y"`
HOST_NAME=`hostname`
IHS_INSTALL_HOME=/usr/IBM/HTTPServer
IHS_CONF_DIR=${IHS_INSTALL_HOME}/conf
UTIL_DIR=/mnt/WAS/WAS_7/utilities
mv ${IHS_CONF_DIR}/httpd.conf ${IHS_CONF_DIR}/httpd.conf_${DATE} 
cp ${UTIL_DIR}/bin/httpd.conf ${IHS_CONF_DIR}
cp ${IHS_CONF_DIR}/admin.conf ${IHS_CONF_DIR}/admin.conf_${DATE}
################################################
perl -e "s/-ServerName-/${HOST_NAME}/g;" -pi_${DATE} $(find  ${IHS_CONF_DIR}/httpd.conf -type f)
################################################
perl -e "s/User\ \@\@SetupadmUser\@\@/User\ nobody/g;" -pi_tmp1 $(find ${IHS_CONF_DIR}/admin.conf -type f)
################################################
perl -e "s/Group\ \@\@SetupadmGroup\@\@/Group\ nobody/g;" -pi_tmp2 $(find ${IHS_CONF_DIR}/admin.conf -type f)
###############################################
rm ${IHS_CONF_DIR}/admin.conf_tmp1
rm ${IHS_CONF_DIR}/admin.conf_tmp2
