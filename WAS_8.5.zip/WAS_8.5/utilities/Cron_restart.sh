#!/usr/bin/ksh

############################################################

PID=`ps -ef | grep -v grep | grep cron | awk '{print $2}'`
kill -9 $PID
