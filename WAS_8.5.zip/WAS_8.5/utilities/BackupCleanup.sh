#!/usr/bin/ksh
# ########################################################################
# Name: "BackupCleanup.sh" 
#
# Description:
# To append the websphere backup config file cleanup script to the crontab and to place the scripts in required location
############################################################################
SW_REP=/mnt/WAS/WAS_7
mkdir -p /usr/perlscripts/cleanup
cd /usr/perlscripts/cleanup
cp ${SW_REP}/utilities/bin/backupRemovel.sh .
chmod 755 *
echo "#Cleanup 2 months old websphere backupconfig files" >> /var/spool/cron/crontabs/root
echo "* 4 * *  6	/usr/perlscripts/cleanup/backupRemovel.sh 1>/dev/null 2>/dev/null" >> /var/spool/cron/crontabs/root
PID=`ps -ef | grep -v grep | grep cron | awk '{print $2}'`
kill -9 $PID
/usr/perlscripts/cleanup/backupRemovel.sh
