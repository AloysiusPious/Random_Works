#!/usr/bin/ksh
# ########################################################################
# Name:  was_ops.sh
#
# Description:
# To append the WebSphere dump file check and backup config script to
# crontab also to place  the scripts in required location
############################################################
SW_REP=/mnt/WAS/WAS_7
mkdir -p /usr/perlscripts/heaptest
cd /usr/perlscripts/heaptest
cp ${SW_REP}/utilities/bin/heaptest.pl .
cp ${SW_REP}/utilities/bin/coretest.pl .
echo "# WebSphere Heap & Core Dump check" >> /var/spool/cron/crontabs/root
echo "0,5,10,15,20,25,30,35,40,45,50,55 * * * * /usr/perlscripts/heaptest/heaptest.pl 1>/dev/null" >> /var/spool/cron/crontabs/root
echo "0,5,10,15,20,25,30,35,40,45,50,55 * * * * /usr/perlscripts/heaptest/coretest.pl 1>/dev/null" >> /var/spool/cron/crontabs/root

mkdir -p /backup/wasbackup/AppSrv01
cd /backup/wasbackup/AppSrv01
cp ${SW_REP}/utilities/bin/wasbackup.ksh .

echo "# WebSphere config backups" >> /var/spool/cron/crontabs/root
echo "30 3 * * 5 /backup/wasbackup/AppSrv01/wasbackup.ksh 1>/dev/null" >> /var/spool/cron/crontabs/root
PID=`ps -ef | grep -v grep | grep cron | awk '{print $2}'`
kill -9 $PID
