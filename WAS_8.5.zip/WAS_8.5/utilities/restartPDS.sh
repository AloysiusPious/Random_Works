############################################################################
#
Mount_Point=/ATTAJ2
Threshold=75
Log_File=/usr/IBM/WebSphere/AppServer/profiles/AppSrv01/logs/Restart_PDS.log
>$Log_File
Fs_Used=`df -k ${Mount_Point} | grep ${Mount_Point} | awk {'print $4'} | sed 's/%//g'`
################################################################
log_it()
{
   echo "$0:$(date +%Y"-"%m"-"%d" "%X)  ${1}" >> ${Log_File}
}
restart_PDS()
{
log_it " Restart Initiated ..."
/usr/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/stopServer.sh server1 >> ${Log_File}
log_it " Sleeping for 10 Seconds."
sleep 10;
/usr/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/startServer.sh server1 >> ${Log_File}
log_it " Restart Completed."
}
#if [ ${Fs_Used} -gt ${Threshold} ];  then
#log_it " Space Utilization on ${Mount_Point} has exceeded the threshhold of ${Threshold} percentage"
#log_it " Restarting websphere service for PDS..."
restart_PDS
#else
#log_it " Space Utilization on ${Mount_Point} has not exceeded the threshhold of ${Threshold} percentage"
#log_it " Ignoring the Restart of Websphere Services for PDS..."
#fi
