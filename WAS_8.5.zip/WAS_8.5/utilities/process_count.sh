#!/bin/ksh


no_of_process=2
log_file="/usr/perlscripts/heaptest/processCheck.txt"
> $log_file
process_count=`ps -ef | grep java | grep -v grep | wc -l`
if [ $no_of_process -gt $process_count ]
then
    echo "not found" > $log_file
fi

