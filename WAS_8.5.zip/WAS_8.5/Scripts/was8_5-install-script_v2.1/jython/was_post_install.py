  #! /usr/bin/ksh
# #################################################################################
#
# Script  : was_post_install.py
#
# Description:
# To add teh username/password entry in soap.client.props file and encode the password,
# to uninstall the default applications, set the Webcontainer SSL transport disable,
# garbage collection as true,PMI as extended and to set the JVM mi,Max heap size,
# and create chain certificate with 5110 days validity replace with default certtificate
##################################################################################
# History
#  1.0 - 11/03/2014 : Aloysius Pious : V1.0 CREATED. Initial Version.
###################################################################################
Version="1.0"
file_Name="was_post_install.py"
###########################Define Funtion-Begin#########################################
def log_it(msg):
    dts = time.strftime('%Y-%m-%d %H:%M:%S')
    print "./" + file_Name + ":" + dts + " " ,msg
#endDef
##############################Define Funtion-End########################################
################Federated Repositary Security Configuration-Begin#######################
def fed_SECURITY():
				log_it ('Adding Global Security With Federated Repositary')
				AdminTask.addFileRegistryAccount('[-userId "'+eval("User_Name")+'" -password "'+eval("Pass_Word")+'" ]')
				AdminConfig.save()
				AdminTask.applyWizardSettings('[-secureApps false -secureLocalResources false -userRegistryType WIMUserRegistry -customRegistryClass com.ibm.ws.wim.registry.WIMUserRegistry -adminName "'+eval("User_Name")+'"  -adminPassword "'+eval("Pass_Word")+'" ]')
				log_it ('Saving Configuration ...')
				AdminConfig.save()
				log_it ('OK')
#endDef
################Federated Repositary Security Configuration-End###########################
#######################UnInstall default applications-Begin##################################
def uninstall_DEFAPP():
				log_it ('Stop DefaultApplication')
				AdminApplication.stopApplicationOnSingleServer("DefaultApplication", nodeName, jvmId)
				log_it ('OK')
				log_it ('Stop ivtApp')
				AdminApplication.stopApplicationOnSingleServer("ivtApp", nodeName, jvmId)
				log_it ('OK')
				log_it ('Stop query')
				AdminApplication.stopApplicationOnSingleServer("query", nodeName, jvmId)
				log_it ('OK')
				log_it ('Uninstall DefaultApplication')
				AdminApplication.uninstallApplication("DefaultApplication")
				log_it ('OK')
				log_it ('Uninstall ivtApp')
				AdminApplication.uninstallApplication("ivtApp")
				log_it ('OK')
				log_it ('Uninstall query')
				AdminApplication.uninstallApplication("query")
				log_it ('OK')
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')
#endDef
#######################UnInstall default applications-End##################################
#######################Set Min & Maximum heap Size for Server1-Begin##########################
def jvm_set_HEAP():
				log_it ('Set JVM Heapsize')
				AdminServerManagement.setJVMProperties(nodeName, jvmId, "", "", minheap, maxheap, "", "",)
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')
#endDef
#######################Set Min & Maximum heap Size for Server1-End##########################
########################################################################################
#######################Disable the https communication on Webcontainer transport########
def chainGetServerName ( aChain ):
        global AdminConfig
        iStart = (aChain.find("/servers/") + 9)
        tempS = aChain[iStart:len(aChain)+1]
        iEnd = (tempS.find("|") - 1)
        serverName = tempS[0:iEnd+1]
        returnValue = serverName
        return returnValue
#endDef
def chainGetName ( aChain ):
        global AdminConfig
        retChainName = AdminConfig.showAttribute(aChain, "name" )
        returnValue = retChainName
        return returnValue
#endDef
def webcont_http_DISABLE():
				for chainE in AdminConfig.list("Chain").split("\n"):
        				#?PROBLEM? (jacl 19) previous FOREACH_ITEM_IN_LIST may need variable.split("xx")
        				chainName = chainGetName(chainE )
        				if (chainName == "WCInboundDefaultSecure"):
                				serverName = chainGetServerName(chainE )
                				if (serverName == "server1"):
                        				print "###Modifying Chain "+chainName+" for "+serverName
                        				AdminConfig.modify(chainE, [["enable", "false"]] )
												#endIf
	      				#endIf
				#endFor
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')
#endDef
#######################################################################################################
###############################set the Garbage Collection as true-Begin######################################
def grbg_COLL():
				jvmId = AdminConfig.getid("/Node:"+nodeName+"/Server:server1/JavaProcessDef:/JavaVirtualMachine:/" )
				print "###Modifying Verbose Garbage Collection mode to "+verboseGarb
				AdminConfig.modify(jvmId,[['verboseModeGarbageCollection', 'true']] )
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')
#endDef
###############################set the Garbage Collection as true-End######################################
##############################set the PMI Monitoring as Extended-Begin########################################
def set_PMI():
				s1 = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:server1/" )
				pmi = AdminConfig.list("PMIService", s1 )
				print "###Modifying PMI to Extended"
				AdminConfig.modify(pmi, [["enable", "true"], ["statisticSet", "extended"]] )
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')
#endDef
##############################set the PMI Monitoring as Extended-Begin########################################
################To create  new certificate chain and replace with default certificate-Begin###################
def ssl_CONF():
				test1=AdminTask.listPersonalCertificates(['-keyStoreName NodeDefaultKeyStore -keyStoreScope (cell):'+cellName+':(node):'+nodeName] )
				log_it ('create  new certificate chain for server')
				AdminTask.createChainedCertificate(['-keyStoreName NodeDefaultKeyStore -keyStoreScope (cell):'+cellName+':(node):'+nodeName+' -certificateAlias '+hostName+'-ssl -rootCertificateAlias root -certificateSize 1024 -certificateCommonName '+hostName+' -certificateOrganization AlRajhi -certificateOrganizationalUnit TSD -certificateLocality -certificateState -certificateZip -certificateCountry SA -certificateValidDays 5475 '])
				############################################Run replace command####################################
				AdminTask.replaceCertificate(['-certificateAlias default -replacementCertificateAlias '+hostName+'-ssl -deleteOldCert true -deleteOldSigners true -keyStoreName NodeDefaultKeyStore -keyStoreScope (cell):'+cellName+':(node):'+nodeName+''])
				log_it ('Replacing it with old certificate')
				#######################################List new certificate############################
				test2=AdminTask.listPersonalCertificates(['-keyStoreName NodeDefaultKeyStore -keyStoreScope (cell):'+cellName+':(node):'+nodeName] )
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')
#endDef
#####################################To create  new certificate chain and replace with default certificate-End#######################################
################################Webserver config creation federation to WebSphere Console-Begin###########
def webServer_CONF():
				log_it ('Adding WebServer configuration to WebSphere console')
				AdminTask.createWebServerByHostName('[-webserverName "'+eval("Web_Name")+'" -templateName IHS -webPort "'+eval("Web_No")+'" -serviceName -webInstallRoot /usr/IBM/HTTPServer -webProtocol HTTP -configurationFile -errorLogfile -accessLogfile -pluginInstallRoot /usr/IBM/HTTPServer/Plugins -webAppMapping ALL -hostName '+hostName+' -platform aix -adminPort 8080 -adminUserID ihsadmin -adminPasswd '+password+' -adminProtocol HTTP]')
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')
#endDef
################################Webserver config creation federation to WebSphere Console-End###########
################################Websphere config for LDAP integration-Begin#############################
def int_LDAP():
				print "###################Running Jython script to Integerate LDAP with Websphere####################"
				log_it ('LDAP Integration Started ...')
				AdminTask.createIdMgrLDAPRepository('[-default true -id wasadminprd -ldapServerType AD -sslConfiguration  -certificateMapMode exactdn -certificateFilter -loginProperties uid]')
				AdminTask.addIdMgrLDAPServer('[-id wasadminprd -host HO-DC01 -bindDN "CN=wasadminprd,OU=Sys & App Service Accounts,OU=Support,OU=Security OUs,OU=Al Rajhi Bank,DC=alrajhi,DC=bank" -bindPassword Qw102030 -authentication simple -referal ignore -sslEnabled false -ldapServerType AD -sslConfiguration -certificateMapMode exactdn -certificateFilter -port 389]')
				AdminTask.addIdMgrRepositoryBaseEntry('[-id wasadminprd -name "CN=wasadminprd,OU=Sys & App Service Accounts,OU=Support,OU=Security OUs,OU=Al Rajhi Bank,DC=alrajhi,DC=bank" -nameInRepository DC=alrajhi,DC=bank]')
				AdminTask.addIdMgrRealmBaseEntry('[-name defaultWIMFileBasedRealm -baseEntry "CN=wasadminprd,OU=Sys & App Service Accounts,OU=Support,OU=Security OUs,OU=Al Rajhi Bank,DC=alrajhi,DC=bank"]')
				AdminTask.mapGroupsToAdminRole('[-roleName administrator -groupids [WASAdministrators@defaultWIMFileBasedRealm ] -accessids ["group:defaultWIMFileBasedRealm/CN=WASAdministrators,OU=Original Security & Distribution Groups,OU=Security & Distribution Groups,OU=Security OUs,OU=Al Rajhi Bank,CN=wasadminprd,OU=Sys & App Service Accounts,OU=Support,OU=Security OUs,OU=Al Rajhi Bank,DC=alrajhi,DC=bank" ]]')
				AdminTask.mapGroupsToAdminRole('[-roleName adminsecuritymanager -accessids ["group:defaultWIMFileBasedRealm/CN=WASAdministrators,OU=Original Security & Distribution Groups,OU=Security & Distribution Groups,OU=Security OUs,OU=Al Rajhi Bank,CN=wasadminprd,OU=Sys & App Service Accounts,OU=Support,OU=Security OUs,OU=Al Rajhi Bank,DC=alrajhi,DC=bank" ] -groupids [WASAdministrators@defaultWIMFileBasedRealm ]]')
				AdminTask.mapGroupsToAuditRole('[-roleName auditor -groupids [WASAdministrators@defaultWIMFileBasedRealm ] -accessids ["group:defaultWIMFileBasedRealm/CN=WASAdministrators,OU=Original Security & Distribution Groups,OU=Security & Distribution Groups,OU=Security OUs,OU=Al Rajhi Bank,CN=wasadminprd,OU=Sys & App Service Accounts,OU=Support,OU=Security OUs,OU=Al Rajhi Bank,DC=alrajhi,DC=bank" ]]') 
				log_it ('OK')
				log_it ('Adding LDAP failover Server ...')
				AdminTask.addIdMgrLDAPBackupServer('[-id wasadminprd -primary_host HO-DC01 -host HO-DC02 -port 389]')
				AdminTask.addIdMgrLDAPBackupServer('[-id wasadminprd -primary_host HO-DC01 -host HO-DC04 -port 389]')			
				AdminTask.addIdMgrLDAPBackupServer('[-id wasadminprd -primary_host HO-DC01 -host DRC-DC02 -port 389]')
				log_it ('OK')
				log_it ('Saving the configuration ...')
				AdminConfig.save( )
				log_it ('OK')
				log_it ('Updating Configuration for \"allowOperationIfReposDown\" ...')
				AdminTask.updateIdMgrRealm('[-name defaultWIMFileBasedRealm -allowOperationIfReposDown true]')
				log_it ('Saving the configuration ...')
				AdminConfig.save( )
				log_it ('OK')
				
#endDef

################################Websphere config Security Audit-Begin###################################
def sec_AUDIT():
				print "####"
				log_it ('Starting security audit configuration ...')
				not_ref=AdminTask.createAuditNotification('[-notificationName Log_Notification -sendEmail false -emailList -logToSystemOut true ]')
				log_it ('creating AuditNotificationMonitor ...')
				print "###",not_ref
				AdminTask.createAuditNotificationMonitor('[-monitorName AuditMonitor -notificationRef '+not_ref+' -enable true ]')
				log_it ('OK')
				log_it ('creating AuditFilter ...')
				auth_ev=AdminTask.createAuditFilter('[-name Authorization_Event -outcome DENIED -eventType SECURITY_AUTHN ]')
				print "###",auth_ev
				AdminTask.getEventFormatterClass('-emitterRef AuditServiceProvider_1173199825608')
				aud_filters=AdminTask.listAuditFiltersByRef()
				words = aud_filters.split(' ')   # use space to separate words
				aud_filter = ','.join(words)   # use space between words
				log_it ('Append auditFilters with new value ...')
				print "###",aud_filter
				AdminTask.modifyAuditEmitter('[-emitterRef AuditServiceProvider_1173199825608 -eventFormatterClass -auditFilters '+aud_filter+''+auth_ev+' -fileLocation $(LOG_ROOT) -maxFileSize 10 -maxLogs 100 ]') 
				log_it ('OK')
				log_it ('Append AuditEventFactory with new value ...')
				print "###",aud_filter
				AdminTask.modifyAuditEventFactory('[-eventFactoryRef AuditEventFactory_1173199825608 -provider AuditServiceProvider_1173199825608 -auditFilters '+aud_filter+''+auth_ev+' -customProperties ]') 
				log_it ('OK')
				AdminTask.modifyAuditPolicy('[-auditEnabled true -auditPolicy NOWARN -auditorId wasadmin -verbose false ]')
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')
#endDef
################################Websphere config Security Audit-End###################################

##########################################################################################
#																				MAIN PROGRAM																		 #
##########################################################################################

##########################################################################################
import sys
import socket
import re
import string
import time
import java.io as javaio
import java.util as util
import os
import tmp
#######################Define the Variable#############################################
cellName = AdminControl.getCell( )
nodeName = AdminControl.getNode( )
hostName = socket.gethostname( )
verboseGarb = "true"
password = "ihspassword"
jvmId = "server1"
minheap = "1024"
maxheap = "2048"
Prof_Name=tmp.Prof_Name_jy
Web_Name=tmp.Web_Name_jy
User_Name=tmp.User_Name_jy
Pass_Word=tmp.Pass_Word_jy
Web_No=tmp.Web_No_jy


#######################################################################################
##########################################################################################
#																			FUNCTION CALL
##########################################################################################
##########################################################################################
fed_SECURITY()
uninstall_DEFAPP()
jvm_set_HEAP()
webcont_http_DISABLE()
grbg_COLL()
set_PMI()
ssl_CONF()
webServer_CONF()
int_LDAP()
sec_AUDIT()
