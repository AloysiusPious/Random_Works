#! /usr/bin/ksh
# #################################################################################
#
# Script  :InsMgr_install.sh
#	IBM Installation Manager Binary Install
#
#History
# 1.0 - 2014-03-06 initial script created by Aloysius Pious (Email:aloysiuspious@alrajhibank.com.sa)

###################################################################################
Version="1.0"
############### ###################################################################
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}

export DISPLAY=""
export LANG=en_us
export JAVA_COMPILER=none
DATE=`date "+%d%m%Y"`
#InsMgrGzipFile="InstalMgr1.6.2_AIX_PPC_WAS_8.5.5.tar.gz"
InsMgrGzipFile="InstalMgr1.7.3_AIX_PPC_WAS_8.5.5.tar.gz"
InsMgrTarFile=`echo "${InsMgrGzipFile}" | awk -F '.gz' '{print $1}'`
InsMgrDir=`echo "${InsMgrTarFile}" | awk -F '.tar' '{print $1}'`
Present_Dir=`pwd`
installdir=/backup/installation
tmpDir=${installdir}/working
WAS_INSTALL_ROOT=/usr/IBM
INST_MGR_HOME=${WAS_INSTALL_ROOT}/InstallationManager/eclipse 

sw_rep()
{
LOG=${tmpDir}/installInsMgr_${DATE}.log
if [ ! -d ${tmpDir} ] ; then
   mkdir -p ${tmpDir}
   if [ $? -ne 0 ] ; then
      log_it "Failed... Unable to create ${tmpDir}"
      exit 5
   fi
fi
   echo "\nPlease Enter Software Installation Repository (/mnt/WAS/WAS_8.5):  \c"
   read answer
   SW_REPOSITORY=${answer:="/mnt/WAS/WAS_8.5"}
   if [ -z "${SW_REPOSITORY}" ] ; then
      echo "\nSoftware Installation Repository Must be Supplied.\n"
      usage
   fi
}


##################################################################
#  Main Processing Starts Here
##################################################################
sw_rep
log_it "Logging this activity to ${LOG}"
log_it "Software Installation started: `date`"
log_it "Info:  HostName=`hostname`"
log_it "Info:  Software Installation Repository=${SW_REPOSITORY}"
log_it "Info:  WAS_USER=`whoami`"
log_it "Info:  INST_MGR_HOME=${INST_MGR_HOME}"
if [ -d ${installdir}/${InsMgrDir} ] ; then
        log_it "${InsMgrDir} Directory found, removing it for Latest File Copying..."
        rm -rf ${installdir}/${InsMgrDir}
        log_it "OK"
fi

log_it "Checking that ${INST_MGR_HOME} doesn't exist...."
if [ -d $INST_MGR_HOME ] ; then
   log_it "Failed.... ${INST_MGR_HOME} already exists...."
   log_it "If Update Installer is already installed, uninstall it first. Otherwise, remove this directory first" 
   exit 8
fi
log_it "OK"

##################################################################
#  Un-pack software ready for product installation
##################################################################
if [ ! -d ${installdir} ] ; then
   mkdir ${installdir}
   if [ $? -ne 0 ] ; then
      log_it "Failed... Unable to create ${installdir}"
      exit 9
   fi
fi
log_it "Copying the IBM Install Manager distribution from Software Installation Repository..."
cp ${SW_REPOSITORY}/${InsMgrGzipFile} ${installdir}
if [ $? -ne 0 ] ; then
   log_it "Failed... Unable to move to ${installdir}"
   exit 9
fi
cd ${installdir}
log_it "gunzipping ${InsMgrGzipFile} file..."
gunzip ${InsMgrGzipFile}
log_it "OK"
log_it "Un-tarring ${InsMgrTarFile} file..."
tar -xf ${InsMgrTarFile}
log_it "OK"
log_it "Applying execute permission to ${InsMgrDir} Directory..."
chmod -R 755 ${InsMgrDir}
log_it "OK"
log_it "removing ${InsMgrTarFile} file..."
rm ${InsMgrTarFile}
log_it "OK"

##################################################################
#  Install Manager Installer product software
##################################################################
# Now, run the install program silently
log_it "Running the silent install program..."
${installdir}/${InsMgrDir}/installc -log ${installdir}/${InsMgrDir}/IBM_IM_log.txt -installationDirectory ${INST_MGR_HOME} -acceptLicense
RC=$?
if [ ${RC} -ne 0 ] ; then
   echo "\n\n\n"
   log_it "***********************************************************************************"
   log_it "***   Failed ...Install Manager install failed with RC=${RC}...Please investigate  ***"
   log_it "***********************************************************************************"
   echo "\n\n\n"
   exit 10
fi
log_it "OK"
log_it "Removing ${installdir}/${InsMgrDir} Directory and Files..."
rm ${installdir}/${InsMgrDir}
log_it "OK"
log_it "Running IBMIM to confirm Install Manager installation..."
echo "------------------------------------------------------------"
${INST_MGR_HOME}/IBMIM -version -silent -nosplash | tee -a ${LOG}
echo "------------------------------------------------------------"
log_it "Done."
exit 0
