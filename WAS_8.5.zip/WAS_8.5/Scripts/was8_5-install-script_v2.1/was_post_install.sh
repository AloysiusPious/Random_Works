  #! /usr/bin/ksh
# #################################################################################
#
# Script  : was_post_install.sh
#
# Description:
# To add teh username/password entry in soap.client.props,ipc.client.props,sas.client.props file and encode the password,
# to uninstall the default applications, set the Webcontainer SSL transport disable,
# garbage collection as true,PMI as extended and to set the JVM mi,Max heap size,
# and create chain certificate with 5110 days validity replace with default certtificate
##################################################################################
# History
# 11/03/2014 : Aloysius Pious : V1.0 CREATED. Initial Version.
###################################################################################
Version="1.0"
############### ###################################################################
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}
##########################Websphere Default Profile Creation##################
profile_CRE()
{
				Was_Root=/usr/IBM/WebSphere/AppServer
				Prof_Dir=/usr/IBM/WebSphere/AppServer/profiles
				log_it "Creating profile ${Prof_Name}..."
				${WAS_INST_HOME}/bin/manageprofiles.sh -create -profileName ${Prof_Name} -profilePath ${PROFILE_HOME} -templatePath ${WAS_INST_HOME}/profileTemplates/default
				log_it "OK"
				log_it "running verification for profile ${Prof_Name}..."
				${WAS_INST_HOME}/bin/ivt.sh server1 ${Prof_Name}
				log_it "OK"
}

##########################Read WAS Username and Password for WAS Console##################
security_Conf()
{
				log_it "Encoding passwords for soap.client.props file ..."
				echo "com.ibm.SOAP.loginPassword=${WAS_ADMIN_PASS}" > ${tmpFile}
				${WAS_INST_HOME}/bin/PropFilePasswordEncoder.sh ${tmpFile} com.ibm.SOAP.loginPassword
				WAS_ADMIN_PASS_ENCODED=`cat ${tmpFile}| grep "com.ibm.SOAP.loginPassword" | awk -F com.ibm.SOAP.loginPassword= '{print $2}'`
				rm ${tmpFile}*
				log_it "OK"
				log_it "Encoding passwords for ipc.client.props file ..."
				echo "com.ibm.IPC.loginPassword=${WAS_ADMIN_PASS}" > ${tmpFile}
				${WAS_INST_HOME}/bin/PropFilePasswordEncoder.sh ${tmpFile} com.ibm.IPC.loginPassword
				WAS_IPC_PASS_ENCODED=`cat ${tmpFile}| grep "com.ibm.IPC.loginPassword" | awk -F com.ibm.IPC.loginPassword= '{print $2}'`
				rm ${tmpFile}*
				log_it "OK"
				log_it "Encoding passwords for sas.client.props file ..."
				echo "com.ibm.CORBA.loginPassword=${WAS_ADMIN_PASS}" > ${tmpFile}
				${WAS_INST_HOME}/bin/PropFilePasswordEncoder.sh ${tmpFile} com.ibm.CORBA.loginPassword
				WAS_SAS_PASS_ENCODED=`cat ${tmpFile}| grep "com.ibm.CORBA.loginPassword" | awk -F com.ibm.CORBA.loginPassword= '{print $2}'`
				rm ${tmpFile}*
				log_it "OK"
					
				##################################################################
				#  Modify soap.client.props
				##################################################################
				SOAP_FILE="${PROFILE_HOME}/properties/soap.client.props"
				log_it "Creating awk file to modify soap.client.props"
				> ${awkfile}
				if [ $? -ne 0 ] ; then
   			log_it "Error: Unable to create ${awkfile}"
				exit 98
				fi
				echo "\$1 ~ /^com.ibm.SOAP.loginUserid=/ {" >> ${awkfile}
				echo "   print (\"com.ibm.SOAP.loginUserid=${WAS_ADMIN_USER}\")" >> ${awkfile}
				echo "}" >> ${awkfile}
				echo "\$1 ~ /^com.ibm.SOAP.loginPassword=/ {" >> ${awkfile}
				echo "   print (\"com.ibm.SOAP.loginPassword=${WAS_ADMIN_PASS_ENCODED}\")" >> ${awkfile}
				echo "}" >> ${awkfile}
				echo "\$1 ~ /^com.ibm.SOAP.securityEnabled=/ {" >> ${awkfile}
				echo "   print (\"com.ibm.SOAP.securityEnabled=true\")" >> ${awkfile}
				echo "}" >> ${awkfile}
				echo "( \$1 !~ /^com.ibm.SOAP.loginUserid=/ ) &&" >> ${awkfile}
				echo "( \$1 !~ /^com.ibm.SOAP.loginPassword=/ ) &&" >> ${awkfile}
				echo "( \$1 !~ /^com.ibm.SOAP.securityEnabled=/ ) {" >> ${awkfile}
				echo "   print (\$0)" >> ${awkfile}
				echo "}" >> ${awkfile}
				
				log_it "Modify soap.client.props file"
				cp -p ${SOAP_FILE} ${SOAP_FILE}.orig 2>/dev/null
				chmod 400 ${SOAP_FILE}.orig
				awk -f ${awkfile} ${SOAP_FILE} > ${SOAP_FILE}.TEMP
				if [ $? -ne 0 ] ; then
   			log_it "ERROR: modifying soap.client.props file"
   				exit 97
				fi
				cp ${SOAP_FILE}.TEMP ${SOAP_FILE}
				if [ $? -ne 0 ] ; then
   				log_it "ERROR: renaming soap.client.props file"
   				exit 96
				fi
				rm ${awkfile}
				rm ${SOAP_FILE}.TEMP
				log_it "OK"
				##################################################################
				#  Modify ipc.client.props
				##################################################################
				IPC_FILE="${PROFILE_HOME}/properties/ipc.client.props"
				log_it "Creating awk file to modify ipc.client.props"
				> ${awkfile}
				if [ $? -ne 0 ] ; then
				   log_it "Error: Unable to create ${awkfile}"
   				exit 98
				fi
				echo "\$1 ~ /^com.ibm.IPC.loginUserid=/ {" >> ${awkfile}
				echo "   print (\"com.ibm.IPC.loginUserid=${WAS_ADMIN_USER}\")" >> ${awkfile}
				echo "}" >> ${awkfile}
				echo "\$1 ~ /^com.ibm.IPC.loginPassword=/ {" >> ${awkfile}
				echo "   print (\"com.ibm.IPC.loginPassword=${WAS_IPC_PASS_ENCODED}\")" >> ${awkfile}
				echo "}" >> ${awkfile}
				echo "\$1 ~ /^com.ibm.IPC.securityEnabled=/ {" >> ${awkfile}
				echo "   print (\"com.ibm.IPC.securityEnabled=true\")" >> ${awkfile}
				echo "}" >> ${awkfile}
				echo "( \$1 !~ /^com.ibm.IPC.loginUserid=/ ) &&" >> ${awkfile}
				echo "( \$1 !~ /^com.ibm.IPC.loginPassword=/ ) &&" >> ${awkfile}
				echo "( \$1 !~ /^com.ibm.IPC.securityEnabled=/ ) {" >> ${awkfile}
				echo "   print (\$0)" >> ${awkfile}
				echo "}" >> ${awkfile}

				log_it "Modify ipc.client.props file"
				cp -p ${IPC_FILE} ${IPC_FILE}.orig 2>/dev/null
				chmod 400 ${IPC_FILE}.orig
				awk -f ${awkfile} ${IPC_FILE} > ${IPC_FILE}.TEMP
				if [ $? -ne 0 ] ; then
   				log_it "ERROR: modifying ipc.client.props file"
   				exit 97
				fi
				cp ${IPC_FILE}.TEMP ${IPC_FILE}
				if [ $? -ne 0 ] ; then
				   log_it "ERROR: renaming ipc.client.props file"
   				exit 96
				fi
				rm ${awkfile}
				rm ${IPC_FILE}.TEMP
				log_it "OK"

				##################################################################
				#  Modify sas.client.props
				##################################################################
				SAS_FILE="${PROFILE_HOME}/properties/sas.client.props"
				log_it "Creating awk file to modify sas.client.props"
				> ${awkfile}
				if [ $? -ne 0 ] ; then
				   log_it "Error: Unable to create ${awkfile}"
   				exit 98
				fi
				echo "\$1 ~ /^com.ibm.CORBA.loginUserid=/ {" >> ${awkfile}
				echo "   print (\"com.ibm.CORBA.loginUserid=${WAS_ADMIN_USER}\")" >> ${awkfile}
				echo "}" >> ${awkfile}
				echo "\$1 ~ /^com.ibm.CORBA.loginPassword=/ {" >> ${awkfile} 
				echo "   print (\"com.ibm.CORBA.loginPassword=${WAS_SAS_PASS_ENCODED}\")" >> ${awkfile}
				echo "}" >> ${awkfile}
				echo "\$1 ~ /^com.ibm.CORBA.securityEnabled=/ {" >> ${awkfile}
				echo "   print (\"com.ibm.CORBA.securityEnabled=true\")" >> ${awkfile}
				echo "}" >> ${awkfile}
				echo "( \$1 !~ /^com.ibm.CORBA.loginUserid=/ ) &&" >> ${awkfile}
				echo "( \$1 !~ /^com.ibm.CORBA.loginPassword=/ ) &&" >> ${awkfile}
				echo "( \$1 !~ /^com.ibm.CORBA.securityEnabled=/ ) {" >> ${awkfile}
				echo "   print (\$0)" >> ${awkfile}
				echo "}" >> ${awkfile}

				log_it "Modify sas.client.props file"
				cp -p ${SAS_FILE} ${SAS_FILE}.orig 2>/dev/null
				chmod 400 ${SAS_FILE}.orig
				awk -f ${awkfile} ${SAS_FILE} > ${SAS_FILE}.TEMP
				if [ $? -ne 0 ] ; then
   				log_it "ERROR: modifying sas.client.props file"
   				exit 97
				fi
				cp ${SAS_FILE}.TEMP ${SAS_FILE}
				if [ $? -ne 0 ] ; then
				   log_it "ERROR: renaming sas.client.props file"
   				exit 96
				fi
				rm ${awkfile}
				rm ${SAS_FILE}.TEMP
				log_it "OK"
}
##################################################################
# Setting Profile shortcuts for frequent accessing Directories
##################################################################
set_ALIAS()
{
				log_it " Creating shorcuts alais for profile dircetory"
				>${WAS_INSTALL_ROOT}/.wasprofile
				echo "alias waslogs='cd /usr/IBM/WebSphere/AppServer/profiles/${Prof_Name}/logs'" >>${WAS_INSTALL_ROOT}/.wasprofile
				echo "alias wasida='cd /usr/IBM/WebSphere/AppServer/profiles/${Prof_Name}/installedApps'" >>${WAS_INSTALL_ROOT}/.wasprofile
				echo "alias ihslogs='cd /usr/IBM/HTTPServer/logs'" >>${WAS_INSTALL_ROOT}/.wasprofile
				echo "alias oprm='/home/sys1/clearlogs.ksh'" >>${WAS_INSTALL_ROOT}/.wasprofile
				echo "alias wasver='/usr/IBM/WebSphere/AppServer/bin/versionInfo.sh | grep -i version'" >>${WAS_INSTALL_ROOT}/.wasprofile
				echo "alias ihsver='/usr/IBM/HTTPServer/bin/versionInfo.sh | grep -i version'" >>${WAS_INSTALL_ROOT}/.wasprofile
				echo "alias plgver='/usr/IBM/Plugins/bin/versionInfo.sh | grep -i version'" >>${WAS_INSTALL_ROOT}/.wasprofile
				echo "alias inmver='/usr/IBM/InstallationManager/eclipse/IBMIM -version -silent -nosplash'" >>${WAS_INSTALL_ROOT}/.wasprofile
				echo ". ${WAS_INSTALL_ROOT}/.wasprofile" >> /.profile
				log_it "OK"
				#########################Kill WAS PID if its running and restart the WAS###############
				#PID=`ps -ef | grep -v grep |grep ${PROFILE_HOME} | awk '{print $2}'`
				#if [ -z "${PID}" ];then
					#log_it " WebSphere process not found...Starting WebSphere process..."
           #				${PROFILE_HOME}/bin/startServer.sh server1
				#else
					#log_it " WebSphere process found...Restarting it to apply soap.client.props changes..."
					#kill -9 ${PID}
	  				#${PROFILE_HOME}/bin/startServer.sh server1
				#fi
}
######################################################################################

######################################################################################
wsadmin_EXE()
{
				log_it "Running Jython scripts to change the configuration..."
				${PROFILE_HOME}/bin/wsadmin.sh -lang jython -f ${JYTHON_DIR}/was_post_install.py
				log_it "Done ."
}
######################################################################################
ldap_HOST()
{
				export DATE=`date "+%Y"-"%m"-"%d"`
				backFile=/backup/EtcHosts_$DATE
				EtcHost=/etc/hosts
				echo "~~~~~~~~~~~~~~~~~~~~~~~~Script processing started~~~~~~~~~~~~~~~~~~~~~~~~~"
				log_it "Taking backup of current /etc/hosts file..."
				cp -p /etc/hosts $backFile 
				log_it "OK"
				log_it "Updating /etc/hosts file with LDAP servers..."
				echo "######Microsoft Active Dircetory Srvers for Websphere Authentication####" >> $EtcHost
				echo "10.11.34.254	DRC-DC02" >> $EtcHost
				echo "10.0.46.51	HO-DC01" >> $EtcHost
				echo "10.0.46.52	HO-DC02" >> $EtcHost
				echo "10.0.90.56	HO-DC04" >> $EtcHost
				log_it "OK"
				echo "~~~~~~~~~~~~~~~~~copy of old /etc/hosts file available at $backFile~~~~~~~~"
}
######################################################################################

######################################################################################
restart_JVM()
{
				log_it "Restarting the WebSphere process..."
				${PROFILE_HOME}/bin/stopServer.sh server1
				${PROFILE_HOME}/bin/startServer.sh server1
				log_it "OK"
}
rm_TMP()
{
rm ${Present_Dir}/tmp.*
}
#######################################################################################
###########	MAIIN PROGRAM					 ##################
#######################################################################################
				export DISPLAY=""
				export LANG=en_us
				DATE=`date "+%d%m%Y"`
				Present_Dir=`pwd`
				echo "\nPlease Enter Profile Name you want to Create (AppSrv01):  \c"
				read answer
				Prof_Name=${answer:="AppSrv01"}
				echo "\nPlease Enter Username for WebSphere Console (wasadmin):  \c"
				read WAS_ADMIN_USER
				WAS_ADMIN_USER=${WAS_ADMIN_USER:="wasadmin"}
				echo "\nPlease Enter Password for WebSphere Console:  \c"
				read WAS_ADMIN_PASS

##########################################################################################
##########################################################################################
tmpDir=${Present_Dir}/logs
LOG=${tmpDir}/was_post_install_${DATE}.log
WAS_INSTALL_ROOT=/usr/IBM
WAS_INST_HOME=${WAS_INSTALL_ROOT}/WebSphere/AppServer
PROFILE_HOME=${WAS_INST_HOME}/profiles/${Prof_Name}
JYTHON_DIR=${Present_Dir}/jython
tmpFile="${Present_Dir}/tmp.txt"
awkfile="${Present_Dir}/tmp.awk"
> ${tmpFile}
if [ $? -ne 0 ] ; then
   log_it "Error: Unable to create ${tmpFile}"
   exit 98
fi
#####Passing Variable to Jython####################################################
> ${Present_Dir}/tmp.py
echo "Prof_Name_jy=\"${Prof_Name}\"" >> ${Present_Dir}/tmp.py
Web_No=`echo ${Prof_Name} | awk -F "0" '{print $2}'`
echo "Web_Name_jy=\"webserver${Web_No}\"" >> ${Present_Dir}/tmp.py
echo "User_Name_jy=\"${WAS_ADMIN_USER}\"" >> ${Present_Dir}/tmp.py
echo "Pass_Word_jy=\"${WAS_ADMIN_PASS}\"" >> ${Present_Dir}/tmp.py
Web_No1=`expr ${Web_No} - 1`
echo "Web_No_jy=\"8${Web_No1}\"" >> ${Present_Dir}/tmp.py


#################################END################################################
#######################################################################################
#					FUNCTION CALL																					#
#Remember to keep below function in same sequential order
#######################################################################################
profile_CRE
#ldap_HOST
security_Conf
set_ALIAS
wsadmin_EXE
restart_JVM
rm_TMP
