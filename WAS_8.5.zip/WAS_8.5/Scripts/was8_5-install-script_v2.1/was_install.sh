#! /usr/bin/ksh
# #################################################################################
#
# Script  : was_install.sh
#	Install WAS 8.5 product binaries
##################################################################################
# History
# 09/03/2014 : Aloysius Pious : V1.0 CREATED. Initial Version.
#
#
#
###################################################################################
Version="1.0"
############### ###################################################################
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}
export DISPLAY=""
export LANG=en_us
export JAVA_COMPILER=none
DATE=`date "+%d%m%Y"`
WasGzipFile="WAS_ND_V8.5.5.tar.gz"
WasTarFile=`echo "${WasGzipFile}" | awk -F '.gz' '{print $1}'`
WasBinDir=`echo "${WasTarFile}" | awk -F '.tar' '{print $1}'`
Present_Dir=`pwd`
installdir=/backup/installation
tmpDir=${Present_Dir}/logs
was_installsource=${installdir}
WAS_INSTALL_ROOT=/usr/IBM
WAS_INST_HOME=${WAS_INSTALL_ROOT}/WebSphere/AppServer
InsMgrTools=${WAS_INSTALL_ROOT}/InstallationManager/eclipse/tools

sw_rep()
{
LOG=${tmpDir}/install_was8_5_${DATE}.log
if [ ! -d ${tmpDir} ] ; then
   mkdir -p ${tmpDir}
   if [ $? -ne 0 ] ; then
      log_it "Failed... Unable to create ${tmpDir}"
      exit 5
   fi
fi

   echo "\nPlease Enter Software Installation Repository (/mnt/WAS/WAS_8.5):  \c"
   read answer
   SW_REPOSITORY=${answer:="/mnt/WAS/WAS_8.5"}
   if [ -z "${SW_REPOSITORY}" ] ; then
      echo "\nSoftware Installation Repository Must be Supplied.\n"
      usage
   fi
}


##################################################################
#  Main Processing Starts Here
##################################################################
sw_rep
log_it "Logging this activity to ${LOG}"
log_it "Software Installation started: `date`"
log_it "Info:  HostName=`hostname`"
log_it "Info:  Software Installation Repository=${SW_REPOSITORY}"
log_it "Info:  WAS_USER=`whoami`"
log_it "Info:  WAS_INST_HOME=${WAS_INST_HOME}"
if [ -d ${installdir}/${WasBinDir} ] ; then
        log_it "${WasBinDir} Directory found, removing it for Latest File Copying..."
        rm -rf ${installdir}/${WasBinDir}
        log_it "OK"
fi

log_it "Checking that ${WAS_INST_HOME} doesn't exist...."
if [ -d $WAS_INST_HOME ] ; then
   log_it "Failed.... ${WAS_INST_HOME} already exists...."
   log_it "If WAS is already installed, uninstall it first. Otherwise, remove this directory first" 
   exit 8
fi
log_it "OK"

##################################################################
#  Un-pack software ready for product installation
##################################################################
log_it "Copying the WAS8.5 distribution from Software Installation Repository..."
#  Un-tar the WAS8.5 distribution 
if [ ! -d ${installdir} ] ; then
   mkdir ${installdir}
   if [ $? -ne 0 ] ; then
      log_it "Failed... Unable to create ${installdir}"
      exit 9
   fi
fi
cp ${SW_REPOSITORY}/${WasGzipFile} ${was_installsource}
if [ $? -ne 0 ] ; then
   log_it "Failed... Unable to move to ${installdir}"
   exit 9
fi
log_it "OK"
cd ${was_installsource}
log_it "Un-zipping ${WasGzipFile} file..."
gunzip ${WasGzipFile}
if [ $? -ne 0 ] ; then
   #rm -rf ${installdir} 2>/dev/null
   log_it "Failed... to gunzip the product distribution"
   exit 9
fi
log_it "OK"
log_it "Un-tarring ${WasTarFile} file..."
tar -xf ${WasTarFile}
if [ $? -ne 0 ] ; then
   #rm -rf ${installdir} 2>/dev/null
   log_it "Failed... to un-tar the product distribution"
   exit 9
fi
log_it "Applying execute permission to ${WasBinDir} Directory..."
chmod -R 755 ${WasBinDir}
log_it "OK"
log_it "removing ${WasTarFile} file..."
rm ${WasTarFile}
log_it "OK"
##################################################################
#  Install WebSphere Application Server product software
##################################################################

# Now, run the install program silently
log_it "Running the WebSphere AppServer silent install program..."
${InsMgrTools}/imcl input ${Present_Dir}/RESPONSEFILES/WAS8_5_Install.txt  -log ${Present_Dir}/logs/tmp_${DATE}.log -acceptLicense -showProgress

RC=$?
if [ ${RC} -ne 0 ] ; then
   echo "\n\n\n"
   log_it "***********************************************************************************"
   log_it "***   Failed ...WebSphere install failed with RC=${RC}...Please investigate	***"
   log_it "***********************************************************************************"
   echo "\n\n\n"
   exit 10
fi
log_it "OK"
log_it "Removing Temporary Files and Dircetory" 
rm -rf ${WasBinDir}
log_it "OK"
log_it "Running versionInfo.sh to confirm WAS installation..."
${WAS_INST_HOME}/bin/versionInfo.sh -maintenancePackages | tee -a ${LOG}
exit 0
