#! /usr/bin/ksh
# #################################################################################
#
# Script  :updi_install.sh
#	IBM Installation Manager Binary UnInstall
#
#History
# 1.0 - 2014-03-06 initial script created by Aloysius Pious (Email:aloysiuspious@alrajhibank.com.sa)

###################################################################################
Version="1.0"
############### ###################################################################
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}

export DISPLAY=""
export LANG=en_us
export JAVA_COMPILER=none
DATE=`date "+%d%m%Y"`
VAR_HOME=/var/ibm

##################################################################
#  unInstall Manager Installer product software
##################################################################
# Now, run the uninstall program silently
log_it "Running the silent uninstall program..."
${VAR_HOME}/InstallationManager/uninstall/uninstallc
RC=$?
if [ ${RC} -ne 0 ] ; then
   echo "\n\n\n"
   log_it "***********************************************************************************"
   log_it "***   Failed ...Install Manager uninstall failed with RC=${RC}...Please investigate  ***"
   log_it "***********************************************************************************"
   echo "\n\n\n"
   exit 10
fi
log_it "OK"
log_it "Done"
exit 0
