#! /usr/bin/ksh
#######################################################################################
#
# aixPreReqCheck.sh - Script to validate AIX Pre-Requisites 
#
# 1.  Check the IHS user and group setup
# 2.  Check file systems exist
# 3.  Check file system sizes
# 4.  Check available space in /tmp
##################################################################################
# History
# 10/03/2014 : Aloysius Pious : V1.0 Initial Version
#
#######################################################################################
Version="1.0"
# ################################################
# Variable setup
# ################################################

DATE=`date "+%d%m%Y"`
echo_out()
{
   if [ $(uname) = "AIX" ] ; then
      echo -e "${1}"
   fi
}
#  Check running as WAS Admin User ...
if [ ! $(whoami) = "root" ] ; then
   echo "\nERROR: Script must be run as the root user"
   echo "Exiting....."
   exit 1
fi

# ################################################
# Functions
# ################################################
validateUser()
{
   # This method checks for the existence of the workload user

   returnValue=0

   IHSUSER=${1}
   IHSGROUP=${1}
 
   uCount=$(cat /etc/passwd | cut -d":" -f1 | grep -c ${IHSUSER})

   if [ ${uCount} -eq 1 ] ; then
      # The apache user has been found
      wlHome=$(grep ${IHSUSER} /etc/passwd | awk -F ":" '{print $6}')

      wlShell=$(grep ${IHSUSER} /etc/passwd | awk -F ":" '{print $7}')

      wlUserGID=$(grep ${IHSUSER}: /etc/passwd | awk -F ":" '{print $4}')

      wlGroupName=$(grep ${wlUserGID} /etc/group | awk -F ":" '{print $1}')
      if [ "${wlGroupName}" != ${IHSGROUP} ] ; then
         echo "ALERT: The primary user group for user ${IHSUSER} is not set to ${IHSGROUP}"
         returnValue=1
      fi
   else
      # No WAS workload user was found
       echo "The ${IHSUSER} does not exist."
      returnValue=1
   fi
      return ${returnValue}
}

validateFileSystem()
{
   returnValue=0

   fsName=${1}
   fsReqSize=${2}
   fsFound=$(df -k | grep -c ${fsName}$)

   if [ ${fsFound} -eq 1 ] ; then
      # Check the file system size

      if [ $(uname) = "AIX" ] ; then
         fsFoundSize=$(df -k | grep ${fsName}$ | awk -F " " '{print $3}')
      fi
      if [ ${fsFoundSize} -lt ${fsReqSize} ] ; then
         
         echo "ALERT: The file system free size of the ${fsName} is below the required size of ${fsReqSize} Kilo Bytes ..."
        # df -k ${fsName}
         #echo "------------------------------------------------------------------------------------------------"
         echo "###"
         returnValue=1
      fi 
   else
      echo "ALERT: The file system ${fsName} does not exist."
      returnValue=1
   fi
   return ${returnValue}
}

validateFileSystems()
{
   if [[ $(uname) = "AIX" ]] ; then
      fsSizeWebSphere=10485760
      fsSizeBackup=8388608
      fsSizeArchive=8388608
      fsSizeVar=596980
      fsSizetmp=971048
   fi 
   returnValue=0

   validateFileSystem /usr/IBM ${fsSizeWebSphere}

   if [ $? -ne 0 ] ; then
      returnValue=1
   fi

   validateFileSystem /backup ${fsSizeBackup}

   if [ $? -ne 0 ] ; then
      returnValue=1
   fi

   validateFileSystem /archive ${fsSizeArchive}

   if [ $? -ne 0 ] ; then
      returnValue=1
   fi

   validateFileSystem /var ${fsSizeVar}

   if [ $? -ne 0 ] ; then
      returnValue=1
   fi
   validateFileSystem /tmp ${fsSizetmp}

   if [ $? -ne 0 ] ; then
   echo $?
      returnValue=1
   fi
   return ${returnValue}
}
##################################################################
#  Main Processing Starts Here
##################################################################
clear
echo "###Script to validate AIX Pre-Requisites for Websphere 8.5 build ..."
PREREQCHECK_FAILED="false"
# 1.  Check the workload user and group setup

echo "\n### IHS user and group verification ###\n"

validateUser apache
if [ $? -eq 0 ] ; then
   echo "INFO: IHS user and group verification successfully completed."
else
   PREREQCHECK_FAILED="true"
fi


echo "\n### File system verification ###\n"

validateFileSystems

if [ $? -eq 0 ] ; then
   echo "INFO: File system verification successfully completed."
else
   PREREQCHECK_FAILED="true"
fi

echo "\n********************************************************************************"
echo "\t\t If any Alert found then correct it before Running the build script"
echo "********************************************************************************"
