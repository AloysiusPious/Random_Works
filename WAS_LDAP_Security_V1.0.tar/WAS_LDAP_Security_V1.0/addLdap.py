#######################################################################################
Version="1.0"
############################was_post_install.py########################################
import sys
import java
import socket
import java.io as javaio
import java.util as util
import os
#######################################################################################
cellName = AdminControl.getCell( )
nodeName = AdminControl.getNode( )
hostName = socket.gethostname( )
jvmId = "server1"
installedApps = AdminApp.list( ).split()
print
print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~WebSphere variable~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
print "		HostName	=", hostName
print "		CellName	=", cellName
print "		NodeName	=", nodeName
print "		JVMName		=", jvmId
print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
print "###################Running Jython script to Integerate LDAP with Websphere####################"
print " Integration Started ..."
AdminTask.createIdMgrLDAPRepository('[-default true -id wasadminprd -ldapServerType AD -sslConfiguration  -certificateMapMode exactdn -certificateFilter -loginProperties uid]')

AdminTask.addIdMgrLDAPServer('[-id wasadminprd -host HO-DC03 -bindDN "CN=wasadminprd,OU=Sys & App Service Accounts,OU=Support,OU=Security OUs,OU=Al Rajhi Bank,DC=alrajhi,DC=bank" -bindPassword Qw102030 -authentication simple -referal ignore -sslEnabled false -ldapServerType AD -sslConfiguration -certificateMapMode exactdn -certificateFilter -port 389]')

AdminTask.addIdMgrRepositoryBaseEntry('[-id wasadminprd -name "CN=wasadminprd,OU=Sys & App Service Accounts,OU=Support,OU=Security OUs,OU=Al Rajhi Bank,DC=alrajhi,DC=bank" -nameInRepository DC=alrajhi,DC=bank]')

AdminTask.addIdMgrRealmBaseEntry('[-name defaultWIMFileBasedRealm -baseEntry "CN=wasadminprd,OU=Sys & App Service Accounts,OU=Support,OU=Security OUs,OU=Al Rajhi Bank,DC=alrajhi,DC=bank"]')
AdminTask.mapGroupsToAdminRole('[-roleName administrator -groupids [WASAdministrators@defaultWIMFileBasedRealm ] -accessids ["group:defaultWIMFileBasedRealm/CN=WASAdministrators,OU=Original Security & Distribution Groups,OU=Security & Distribution Groups,OU=Security OUs,OU=Al Rajhi Bank,CN=wasadminprd,OU=Sys & App Service Accounts,OU=Support,OU=Security OUs,OU=Al Rajhi Bank,DC=alrajhi,DC=bank" ]]')
AdminTask.mapGroupsToAdminRole('[-roleName adminsecuritymanager -accessids ["group:defaultWIMFileBasedRealm/CN=WASAdministrators,OU=Original Security & Distribution Groups,OU=Security & Distribution Groups,OU=Security OUs,OU=Al Rajhi Bank,CN=wasadminprd,OU=Sys & App Service Accounts,OU=Support,OU=Security OUs,OU=Al Rajhi Bank,DC=alrajhi,DC=bank" ] -groupids [WASAdministrators@defaultWIMFileBasedRealm ]]')
print " OK "
print " Adding LDAP failover Server ..."
AdminTask.addIdMgrLDAPBackupServer('[-id wasadminprd -primary_host HO-DC03 -host HO-DC01 -port 389]')
AdminTask.addIdMgrLDAPBackupServer('[-id wasadminprd -primary_host HO-DC03 -host HO-DC04 -port 389]')
AdminTask.addIdMgrLDAPBackupServer('[-id wasadminprd -primary_host HO-DC03 -host DRC-DC01 -port 389]')
AdminTask.addIdMgrLDAPBackupServer('[-id wasadminprd -primary_host HO-DC03 -host DRC-DC02 -port 389]')
print " OK "
print " Saving the configuration ..."
AdminConfig.save( )
print " OK "
print " Script execution completed...."
