#! /usr/bin/ksh
# #################################################################################
#
# Script  :addLdap.sh 
#
# Description:
###################################################################################
# This script to integrate the  Active dircetory server with Websphere
###################################################################################
#History
# 1:0 15-October-2012 : initial script created by Aloysius Pious
###################################################################################
Version="1.0"
############### ###################################################################
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}
#####################################################################################
#				Variable Declaration
#####################################################################################
export DISPLAY=""
DATE=`date "+%d%m%Y"`
Present_Dir=`pwd`
WAS_INSTALL_ROOT=/usr/IBM
WAS_INST_HOME=${WAS_INSTALL_ROOT}/WebSphere/AppServer
PROFILE_HOME=${WAS_INST_HOME}/profiles/AppSrv01
CELL_PATH=${PROFILE_HOME}/config/cells
CELL_NAME=`ls -1 ${CELL_PATH}`
NODE_PATH=${CELL_PATH}/${CELL_NAME}/nodes
NODE_NAME=`ls -1 ${NODE_PATH}`
tmpFile="/${Present_Dir}.tmp"
awkfile="/${Present_Dir}/tmp.awk"
propFile=$1
WORK_PROP=$1.working
clear
echo
echo
echo
echo
echo "#################################LDAP Integration Script Version : ${Version}###############################" 
echo 
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
log_it "Running Jython scripts to change the configuration..."
${PROFILE_HOME}/bin/wsadmin.sh -lang jython -f ${Present_Dir}/addLdap.py
log_it "OK"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
log_it " Restarting the JVM ..." 
${PROFILE_HOME}/bin/stopServer.sh server1
${PROFILE_HOME}/bin/startServer.sh server1
log_it "OK"
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~LDAP security added to Websphere~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
