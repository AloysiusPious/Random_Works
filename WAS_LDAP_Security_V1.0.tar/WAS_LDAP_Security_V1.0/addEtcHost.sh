#! /usr/bin/ksh
# #################################################################################
#
# Script  :addEtcHost.sh
#
# Description:
###################################################################################
# This script to update the /etc/hosts file with Active dircetory servers
###################################################################################
#History
# 1:0 17-October-2012 : initial script created by Aloysius Pious
###################################################################################
Version="1.0"
############### ###################################################################
export DATE=`date "+%Y"-"%m"-"%d"`
backFile=/backup/EtcHosts_$DATE
EtcHost=/etc/hosts
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}
clear

echo "~~~~~~~~~~~~~~~~~~~~~~~~Script processing started~~~~~~~~~~~~~~~~~~~~~~~~~"
log_it "Taking backup of current /etc/hosts file..."
cp -p /etc/hosts $backFile 
log_it "OK"
log_it "Updating /etc/hosts file with LDAP servers..."
echo "######Microsoft Active Dircetory Srvers for Websphere Authentication####" >> $EtcHost
echo "10.11.34.254	DRC-DC01" >> $EtcHost
echo "10.11.46.52	DRC-DC02" >> $EtcHost
echo "10.0.46.51	HO-DC01" >> $EtcHost
echo "10.0.31.254	HO-DC03" >> $EtcHost
echo "10.0.90.56	HO-DC04" >> $EtcHost
log_it "OK"
echo "~~~~~~~~~~~~~~~~~copy of old /etc/hosts file available at $backFile~~~~~~~~"
