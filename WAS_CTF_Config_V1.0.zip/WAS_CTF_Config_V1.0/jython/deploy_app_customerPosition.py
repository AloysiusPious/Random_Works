######################################################################################
#
# Script  : deploy_app_customerPosition.py
#
######################################################################################
##
#History
#1.0 : 30-9-2013- Initial script created by Aloysius Pious
######################################################################################
Version="1.0"
file_Name="deploy_app_customerPosition.py"
######################################################################################
def isApplicationRunning(applicationName, serverName, nodeName) :
				return AdminControl.completeObjectName("type=Application,name=%s,process=%s,node=%s,*" % (applicationName, serverName, nodeName)) != ""
###############################Application Deployment-Begin##############################
def DEPLOY_APP():
				print "#########################Uninstalling / Installing Applications###########"
				#Get the name of the WAR file:
				strAppToInstall = filePath1[filePath1.rfind("/")+1:len(filePath1)];
				#Uninstall the app if already deployed.
				appToUninstall = ""
				#appsBefore = AdminApp.list().split("\n");
				appsBefore = AdminApp.list().splitlines();
				for iApp in appsBefore:    
												if (str(iApp) == app_Name):
        												appToUninstall = iApp
        												appToUninstall = str(appToUninstall).strip();
    		#Install the app
				print "###Installing ", strAppToInstall, " from ", filePath1;
				AdminApp.install(filePath1, "-contextroot /"+contextRoot+" -defaultbinding.virtual.host default_host -usedefaultbindings");    
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')    
#endDef
###############################Application Deployment-End##############################
###############################Application UnInstall-Begin##############################
def UNINSTALL_APP():
				print "#########################Uninstalling / Installing Applications###########"
				#Get the name of the WAR file:
				strAppToInstall = filePath1[filePath1.rfind("/")+1:len(filePath1)];
				#Uninstall the app if already deployed.
				appToUninstall = ""
				#appsBefore = AdminApp.list().split("\n");
				appsBefore = AdminApp.list().splitlines();
				for iApp in appsBefore:    
												if (str(iApp) == app_Name):
        												appToUninstall = iApp
        												print "###Uninstalling app: ", appToUninstall
        												appToUninstall = str(appToUninstall).strip();
       													AdminApp.uninstall(appToUninstall)
       													log_it ('Saving Configuration ...')
       													AdminConfig.save();
				log_it ('OK')    
#endDef
###############################Application UnInstall-End##############################
###############################Application UPDATE-Begin##############################
def UPDATE_APP():
				AdminConfig.save( )
				print "#########################Updating Applications###########"		
				AdminApp.update('customerPositionEAR', 'app', '[ -operation update -contents "'+eval("ear_Path")+'" -nopreCompileJSPs -installed.ear.destination $(APP_INSTALL_ROOT)/'+cellName+' -distributeApp -nouseMetaDataFromBinary -nodeployejb -createMBeansForResources -noreloadEnabled -nodeployws -validateinstall warn -noprocessEmbeddedConfig -filepermission .*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755 -noallowDispatchRemoteInclude -noallowServiceRemoteInclude -asyncRequestDispatchType DISABLED -nouseAutoLink -MapModulesToServers [[ "CP Application" customerPositionWeb.war,WEB-INF/web.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ]]]' ) 
				#AdminApp.update('customerPosition', 'app', '[ -operation update -contents "'+eval("ear_Path")+'" -nopreCompileJSPs -installed.ear.destination $(APP_INSTALL_ROOT)/'+cellName+' -distributeApp -nouseMetaDataFromBinary -deployejb -createMBeansForResources -noreloadEnabled -nodeployws -validateinstall warn -noprocessEmbeddedConfig -filepermission .*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755 -noallowDispatchRemoteInclude -noallowServiceRemoteInclude -asyncRequestDispatchType DISABLED -nouseAutoLink -MapModulesToServers [[ eflow-ejb.jar eflow-ejb.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver2 ][ eflow eflow-web.war,WEB-INF/web.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver2 ]]]' ) 
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')    
#endDef
###############################Application UPDATE-End##############################
###############################Application Start-Begin##############################
def START_APP():
				#Start the app 
				apps = AdminApp.list().splitlines(); 
				theApp = ""    
				for iApp in apps:
								if (str(iApp) == app_Name):
        								theApp = iApp;
												#serverstatus = AdminControl.completeObjectName('type=Application,name=theApp,*')
        								status = isApplicationRunning(theApp, serverName, nodeName)
        								#print status
        								print "#########################Starting Application############################"   
        								print "###Starting App: ", theApp
        								if (status == 0):
																appManager = AdminControl.queryNames('cell='+cellName+',node='+nodeName+',type=ApplicationManager,process='+serverName+',*')
																AdminControl.invoke(appManager, 'startApplication', theApp)
																log_it('Application is in stopped state and started successfuly!')
												#endIF
        								if (status == 1):
																log_it('Application already is in running state!')
												#endIF
				log_it ('OK')
#endDef
###############################Application Start-End##############################
###############################Application Stop-Begin##############################
def STOP_APP():
				#Stop the app 
				apps = AdminApp.list().splitlines(); 
				theApp = ""    
				#app_Name= app_Name
				for iApp in apps:
								if (str(iApp) == app_Name):
        								theApp = iApp;
												#serverstatus = AdminControl.completeObjectName('type=Application,name=theApp,*')
        								status = isApplicationRunning(theApp, serverName, nodeName)
        								print "#########################Stoping Application############################"   
        								#print status
        								print "###Stopping App: ", theApp
        								if (status == 1):
																appManager = AdminControl.queryNames('cell='+cellName+',node='+nodeName+',type=ApplicationManager,process='+serverName+',*')
																AdminControl.invoke(appManager, 'stopApplication', theApp)
																log_it('Application in runing state and stopped successfuly!')
												#endIF
        								if (status == 0):
																log_it('Application already in stopped state!')
												#endIF
				log_it ('OK')
#endDef
###############################Application Stop-End##############################
###############################Map Module to WebServer-Begin##############################
def MAP_WEBSERVER():
				print "#########################Mapping Web Module to WebServer############################"
				string = AdminApp.listModules(''+eval("app_Name")+'', '-server')
				#string1 = string.replace('#', ' ')
				string = string.split('#')
				string1 = string[1].split('+')
				mapto='[[ '+string1[0]+' '+string1[0]+',WEB-INF/web.xml WebSphere:cell='+cellName+',node='+nodeName+',server='+serverName+'+WebSphere:cell='+cellName+',node='+nodeName+',server='+web_serverName+' ]]'
				AdminApp.edit(''+eval("app_Name")+'', '[ -MapModulesToServers '+mapto+']' ) 
				log_it('Application Mapped to Webserver successfuly!')
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')
#endDef
###############################Map Module to WebServer-End################################
######################Application Shared Library Mapping-Begin########################
def SHAREDLIB_MAP():
				print "#########################Mapping Shared Library############################"
				print "###Mapping Shared Library for the App: ", app_Name
				AdminApp.edit(''+eval("app_Name")+'', '[ -MapSharedLibForMod [[ "'+eval("app_Name")+'" META-INF/application.xml "'+eval("prop.shrd_Lib")+'"]]]' )
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK') 
#endDef
######################Application Shared Library Mapping-End########################

##########################################################################################
##########################################################################################
#																				MAIN PROGRAM																		 #
##########################################################################################
##########################################################################################
#Uncomment below functions which you want to do the configuration changes, Keep it 
#commented those functions are required 
##########################################################################################
import sys
import socket
import re
import string
import time
import prop
import tmp
#######################Define the Variable#############################################    
cellName = AdminControl.getCell( )
nodeName = AdminControl.getNode( )
hostName = socket.gethostname( )
serverName = prop.server_Name
web_serverName = prop.web_serverName
app_Name = prop.app_Name
ear_Path = prop.ear_Path
server_Id = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:"+serverName+"/" )
WebContainerId = AdminConfig.list("WebContainer", server_Id )
jvmId = AdminConfig.getid("/Node:"+nodeName+"/Server:"+serverName+"/JavaProcessDef:/JavaVirtualMachine:/" )
########################################END#############################################
###########################Define Log_it-Begin#########################################
def log_it(msg):
    dts = time.strftime('%Y-%m-%d %H:%M:%S')
    print "./jython/" + file_Name + ":" + dts + " " ,msg
#endDef
##############################Log_it-End########################################
#######################################################################################
print '-------------------------------------------------------------------'
print "\tRetrived parameter from Installed Websphere :\n"
print "\tCell: "+cellName+"\n\tNode: "+nodeName+"\n\tServer: "+serverName
print '-------------------------------------------------------------------'
#######################################################################################

#numberOfArgs = len(sys.argv)
#if numberOfArgs < 2:
 #   print "Usage: deploy_app_customerPosition.py {file-absolute-path} {context-root}"
#else:
    #Get the absolute path of the WAR file and replace \ with / 
filePath1 = prop.ear_Path
#filePath1 = filePath1.replace('\\', '/')  ####Usefull for windows deployment
contextRoot = ""
####################################Function Call##################################
#STOP_APP() ===> Stopping already Installed Applications
#UNINSTALL_APP()===> Uninstall existing application
#UPDATE_APP()===> Updating Application
#DEPLOY_APP()===> EAR file Deployment funtion, refer to "deploy_app_customerPosition.prop" for required 
#									Parameters for application deployment
#SHAREDLIB_MAP()===> Shared Library reference mapping as defined in property file
#START_APP()===> Starting Application after the deployment
#MAP_WEBSERVER(===> Mapping application module to webserver target(will work for the EAR 
#							 file has only one "WAR" module) for multiple "WAR" mapping please comment
#							 below "MAP_WEBSERVER()" function and map it to webserver manually after deployment
####################################################################################
STOP_APP()
#UNINSTALL_APP()
#DEPLOY_APP()
UPDATE_APP()
#SHAREDLIB_MAP()
#MAP_WEBSERVER()
START_APP()
