strAppToInstallTrim="CTF"
