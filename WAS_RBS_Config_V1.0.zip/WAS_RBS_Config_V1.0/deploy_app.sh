#! /usr/bin/ksh
# ####################################################################################
#
# Script  : deploy_app.sh
#
# Description: Deployment Script for procesing property files and calling jyhton Script
#								and for JVM and HTTP restart
# Author : Aloysius Pious
# Email  : aloysiuspious@alrajhibank.com.sa
#######################################################################################
#History
# 1.0 initial script created by Aloysius Pious
#######################################################################################
Version="1.0"
###################################################################################
##############################Logging Funtion-Begin#################################
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}
##############################Logging Funtion-End####################################
########################JVM Restart Function###########################################
restart_JVM()
{
log_it "Restarting the WebSphere process..."
${PROFILE_HOME}/bin/stopServer.sh server1
${PROFILE_HOME}/bin/startServer.sh server1
log_it "OK"
}
######################################################################################
########################JVM Restart Function###########################################
stop_HTTP()
{
log_it "Stoping the HTTP process..."
/usr/IBM/HTTPServer/bin/apachectl stop
log_it "OK"
}
######################################################################################
########################JVM Restart Function###########################################
start_HTTP()
{
log_it "Starting the HTTP process..."
/usr/IBM/HTTPServer/bin/apachectl start
log_it "OK"
}
######################################################################################
deploy_APP()
{
log_it "Running Jython scripts to change the configuration..."
${PROFILE_HOME}/bin/wsadmin.sh -lang jython -f ${Present_Dir}/jython/deploy_app.py | tee -a ${LOG}
log_it "Done."
}
######################################################################################
rm_TMP()
{
rm ${Present_Dir}/prop.py
rm ${Present_Dir}/tmp.py
rm ${Present_Dir}/*.class
}
##########################################################################################


##########################################################################################
#																				MAIN PROGRAM																		 #
##########################################################################################
##########################################################################################
######################Reading property File for Profile Name#######################
. ./props/deploy_app.prop
###################################################################################
export DISPLAY=""
NOW=$(date +"%F")
NOWT=$(date +"%T")
LOG="./logs/${NOW}-${NOWT}_deploy_app.log"
DATE=`date "+%d%m%Y"`
Present_Dir=`pwd`
PROFILE_NAME=${PROFILE_NAME}
WAS_INSTALL_ROOT=/usr/IBM
WAS_INST_HOME=${WAS_INSTALL_ROOT}/WebSphere/AppServer
PROFILE_HOME=${WAS_INST_HOME}/profiles/${PROFILE_NAME}
if [ ! -d ${PROFILE_HOME} ] ; then
   log_it "Failed... ${PROFILE_HOME} not found"
exit 0
fi
#######################################################################################
############################Processing Property Files###################################
clear
print "\n\n"
print "######### Websphere Application Server Configutaion for Specific Applications#########"
echo "---------------------------------------------------------------------------------"
log_it "Start executing the Script ..."
>${Present_Dir}/prop.py
>${Present_Dir}/tmp.py
grep "^[^#;]" ${Present_Dir}/props/deploy_app.prop  > ${Present_Dir}/prop.py
echo "strAppToInstallTrim=\"`echo ${ear_Path} | awk -F '/' '{print $NF}' | rev | cut -c 5- | rev`\"" > ${Present_Dir}/tmp.py
#########Keep only latest 3 log files and delete others from current directory#######
count=`find . -type f -name "*deploy_app.log" | wc -l`
if [ $count -gt 3 ]
then 
    log_it "Deleting old logs files ..."
		rm `ls -t ./logs/*deploy_app.log | awk 'NR>3'`
		log_it "OK"
else
		log_it "No old log files found ..."
		log_it "OK"
fi 
#######################################################################################
####################################Function Call##################################
stop_HTTP
deploy_APP
rm_TMP
restart_JVM
start_HTTP
###################################################################################

