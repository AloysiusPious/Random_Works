
#! /usr/bin/ksh
# ####################################################################################
#
# Script  : dataSource_db2_ConnPool.sh
#
# Description: DB2 connection pool DataSource creation script for Websphere
# Author : Aloysius Pious
# Email  : aloysiuspious@alrajhibank.com.sa
#######################################################################################
#History
# 1.0 initial script created by Aloysius Pious
#######################################################################################
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}
export DISPLAY=""
NOW=$(date +"%F")
NOWT=$(date +"%T")
LOG="./logs/${NOW}-${NOWT}_dataSource_db2_ConnPool.log"
DATE=`date "+%d%m%Y"`
Present_Dir=`pwd`
PROFILE_NAME=AppSrv01
WAS_INSTALL_ROOT=/usr/IBM
WAS_INST_HOME=${WAS_INSTALL_ROOT}/WebSphere/AppServer
PROFILE_HOME=${WAS_INST_HOME}/profiles/${PROFILE_NAME}

if [ ! -d ${PROFILE_HOME} ] ; then
   log_it "Failed... ${PROFILE_HOME} not found"
exit 0
fi
#######################################################################################
############################Processing Property Files###################################
clear
print "\n\n"
print "######### Websphere Application Server Configutaion for Specific Applications#########"
echo "---------------------------------------------------------------------------------"
log_it "Start executing the Script ..."
>${Present_Dir}/tmp.py
>${Present_Dir}/prop.py
grep "^[^#;]" ${Present_Dir}/props/dataSource_db2_ConnPool.prop  > ${Present_Dir}/prop.py
echo "###########Number of Datasource needed################" >> ${Present_Dir}/tmp.py
no_of_ds=`grep jndi_name ${Present_Dir}/prop.py | grep "^[^#;]"| wc -l`
no_of_ds=`echo ${no_of_ds} | sed -e 's/^ *//' -e 's/ *$//'`   ##Remove blank space from variable
echo "no_of_ds=${no_of_ds}" >> ${Present_Dir}/tmp.py
echo "###########Number of JDBC Provider needed################" >> ${Present_Dir}/tmp.py
no_of_jdbc_prov=`grep db_type ${Present_Dir}/prop.py | grep "^[^#;]" |wc -l`
no_of_jdbc_prov=`echo ${no_of_jdbc_prov} | sed -e 's/^ *//' -e 's/ *$//'`   		##Remove blank space from variable
echo "no_of_jdbc_prov=${no_of_jdbc_prov}" >> ${Present_Dir}/tmp.py
echo "###########Number of JDBC Provider needed################" >>${Present_Dir}/tmp.py
no_auth_alias=`grep auth_alias ${Present_Dir}/prop.py | grep "^[^#;]" |wc -l`
no_auth_alias=`echo ${no_auth_alias} | sed -e 's/^ *//' -e 's/ *$//'`   				##Remove blank space from variable
echo "no_auth_alias=${no_auth_alias}" >> ${Present_Dir}/tmp.py
echo "###########Number of JDBC Provider needed################" >>${Present_Dir}/tmp.py
no_custom_property=`grep custom_property ${Present_Dir}/prop.py | grep "^[^#;]" |wc -l`
no_custom_property=`echo ${no_custom_property} | sed -e 's/^ *//' -e 's/ *$//'`  					 ##Remove blank space from variable
#no_custom_property=$((no_custom_property*no_of_ds))
echo "no_custom_property=${no_custom_property}" >> ${Present_Dir}/tmp.py
c=0
while [[ $c -lt ${no_of_ds} ]]
do
   custom_property="ds_name${c}_custom_property"
   ds_custom_property=`grep ${custom_property} ${Present_Dir}/prop.py | grep "^[^#;]" |wc -l`
   no_custom_property=`echo ${ds_custom_property} | sed -e 's/^ *//' -e 's/ *$//'`  					 ##Remove blank space from variable
   echo "${custom_property}=${no_custom_property}" >> ${Present_Dir}/tmp.py
   let c=c+1
done
#########Keep only latest 2 log files and delete others from current directory#######
count=`find . -type f -name "*dataSource_db2_ConnPool.log" | wc -l`
if [ $count -gt 2 ]
then 
    log_it "Deleting old logs files ..."
		rm `ls -t ./logs/*dataSource_db2_ConnPool.log | awk 'NR>2'`
		log_it "OK"
else
		log_it "No old log files found ..."
		log_it "OK"
fi 
#######################################################################################
########################JVM Restart Function###########################################
restart_JVM()
{
log_it "Restarting the WebSphere process..."
${PROFILE_HOME}/bin/stopServer.sh server1
${PROFILE_HOME}/bin/startServer.sh server1
log_it "OK"
}
######################################################################################
wsadmin_EXE()
{
log_it "Running Jython scripts to change the configuration..."
${PROFILE_HOME}/bin/wsadmin.sh -lang jython -f ${Present_Dir}/jython/dataSource_db2_ConnPool.py | tee -a ${LOG}
log_it "Done."
}
######################################################################################
rm_TMP()
{
rm ${Present_Dir}/prop.py
rm ${Present_Dir}/tmp.py
rm ${Present_Dir}/*.class
}

######################################################################################
##												#Function Call																						##
######################################################################################
wsadmin_EXE
rm_TMP
######################################################################################