######################################################################################
#
# Script  : deploy_app.py
#
######################################################################################
##
#History
#1.0 : 30-9-2013- Initial script created by Aloysius Pious
######################################################################################
Version="1.0"
file_Name="deploy_app.py"
######################################################################################
def isApplicationRunning(applicationName, serverName, nodeName) :
				return AdminControl.completeObjectName("type=Application,name=%s,process=%s,node=%s,*" % (applicationName, serverName, nodeName)) != ""
###############################Application Deployment-Begin##############################
def DEPLOY_APP():
				print "#########################Uninstalling / Installing Applications###########"
				#Get the name of the WAR file:
				strAppToInstall = filePath1[filePath1.rfind("/")+1:len(filePath1)];
				#Uninstall the app if already deployed.
				appToUninstall = ""
				#appsBefore = AdminApp.list().split("\n");
				appsBefore = AdminApp.list().splitlines();
				for iApp in appsBefore:    
												if (str(iApp) == tmp.strAppToInstallTrim):
        												appToUninstall = iApp
        												appToUninstall = str(appToUninstall).strip();
    		#Install the app
				print "###Installing ", strAppToInstall, " from ", filePath1;
				AdminApp.install(filePath1, "-contextroot /"+contextRoot+" -defaultbinding.virtual.host default_host -usedefaultbindings");    
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')    
#endDef
###############################Application Deployment-End##############################
###############################Application UnInstall-Begin##############################
def UNINSTALL_APP():
				print "#########################Uninstalling / Installing Applications###########"
				#Get the name of the WAR file:
				strAppToInstall = filePath1[filePath1.rfind("/")+1:len(filePath1)];
				#Uninstall the app if already deployed.
				appToUninstall = ""
				#appsBefore = AdminApp.list().split("\n");
				appsBefore = AdminApp.list().splitlines();
				for iApp in appsBefore:    
												if (str(iApp) == tmp.strAppToInstallTrim):
        												appToUninstall = iApp
        												print "###Uninstalling app: ", appToUninstall
        												appToUninstall = str(appToUninstall).strip();
       													AdminApp.uninstall(appToUninstall)
       													log_it ('Saving Configuration ...')
       													AdminConfig.save();
				log_it ('OK')    
#endDef
###############################Application UnInstall-End##############################
###############################Application UPDATE-Begin##############################
def UPDATE_APP():
				AdminConfig.save( )
				print "#########################Updating Applications###########"
				AdminApp.update('RbsEAR', 'app', '[ -operation update -contents /usr/IBM/WebSphere/AppServer/profiles/AppSrv01/installableApps/RbsEAR.ear -usedefaultbindings -defaultbinding.ejbjndi.prefix ejb -defaultbinding.virtual.host default_host -defaultbinding.force -nopreCompileJSPs -installed.ear.destination $(APP_INSTALL_ROOT)/'+cellName+' -distributeApp -nouseMetaDataFromBinary -nodeployejb -createMBeansForResources -noreloadEnabled -nodeployws -validateinstall warn -noprocessEmbeddedConfig -filepermission .*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755 -noallowDispatchRemoteInclude -noallowServiceRemoteInclude -asyncRequestDispatchType DISABLED -nouseAutoLink -BindJndiForEJBNonMessageBinding [[ CommonCAEJB.jar CommonSignatureBean CommonCAEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ CommonCAEJB.jar CommCurrAccControllerBean CommonCAEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ CommonCAEJB.jar CommonCADataBean CommonCAEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ CommonCIFEJB.jar CustomerManagementBean CommonCIFEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ CommonCIFEJB.jar CIFControllerBean CommonCIFEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB DeskController FrameworkEJB.jar,META-INF/ejb-jar.xml ejb/it/elsag/common/desk/ejb/facade/DeskControllerHome "" "" ][ FrameworkEJB WorkflowEngineBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB CentralizedControllerBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB AuthorizationBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB ConnectionBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB ValueItemsControllerBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB LBTControllerBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB AccountingBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB LogBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB ProfilesBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB SMSSenderBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB GlobalDataBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB BalancingControllerBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB TacServiceBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB RatesBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ FrameworkEJB WorkflowRelationBean FrameworkEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCAEJB.jar CurrAccExControllerBean RbsCAEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCAEJB.jar CADataBean RbsCAEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCAEJB.jar InvestmentTypeControllerBean RbsCAEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCAEJB.jar SignatureControllerBean RbsCAEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCAEJB.jar MusafirCardControllerBean RbsCAEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCAEJB.jar BookedEntryControllerBean RbsCAEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCAEJB.jar VostroCaFacadeBean RbsCAEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCAEJB.jar CurrAccControllerBean RbsCAEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsDdmsEJB.jar DDMSOriginatorRelationsBean RbsDdmsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsDdmsEJB.jar DdmsDataBean RbsDdmsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsDdmsEJB.jar DDMSOriginatorBean RbsDdmsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsDdmsEJB.jar DdmsControllerBean RbsDdmsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsDdmsEJB.jar DDMSParticipantBean RbsDdmsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsMiscEJB.jar BLMBean RbsMiscEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsMiscEJB.jar ERStatisticsBean RbsMiscEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsMiscEJB.jar PADAuthorizationBean RbsMiscEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsMiscEJB.jar InsuranceControllerBean RbsMiscEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsMiscEJB.jar AtmFilesBean RbsMiscEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsMiscEJB.jar BulletinBoardBean RbsMiscEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsGLEJB.jar GLControllerBean RbsGLEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ CommonTCEJB.jar ComTcControllerBean CommonTCEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsBaEJB.jar BaDataBean RbsBaEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsBaEJB.jar BaControllerBean RbsBaEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsBaEJB.jar CaBundleControllerBean RbsBaEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsBaEJB.jar BaWorkflowBean RbsBaEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsSTCEJB.jar STCFilesBean RbsSTCEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ BricEJB.jar BricControllerBean BricEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCashEJB.jar CashControllerBean RbsCashEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsBVEJB.jar BlankValuesControllerBean RbsBVEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsChequesEJB.jar ChequesControllerBean RbsChequesEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsChequesEJB.jar ChequesbookControllerBean RbsChequesEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsDraftEJB.jar DraftControllerBean RbsDraftEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsDraftEJB.jar DraftStopControllerBean RbsDraftEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsEREJB.jar ERControllerBean RbsEREJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsEREJB.jar ERRoutingControllerBean RbsEREJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsPaymentsEJB.jar PaymentsControllerBean RbsPaymentsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsPaymentsEJB.jar PostTransControllerBean RbsPaymentsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsLPEJB.jar LocalPaymentControllerBean RbsLPEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsMudarabahEJB.jar MudarabahManagementBean RbsMudarabahEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsMudarabahEJB.jar MudarabahDataBean RbsMudarabahEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsLoanEJB.jar LoanControllerBean RbsLoanEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsBillsEJB.jar BillsControllerBean RbsBillsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsTCEJB.jar TCControllerBean RbsTCEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCardManagementEJB.jar CardManagementControllerBean RbsCardManagementEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCardManagementEJB.jar ERemittanceControllerBean RbsCardManagementEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsSafeBoxEJB.jar RbsSafeBoxControllerBean RbsSafeBoxEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsClaimsEJB.jar ClaimsDataControllerBean RbsClaimsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsClaimsEJB.jar ClaimsControllerBean RbsClaimsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsShareDividendsEJB.jar ShareDividendsControllerBean RbsShareDividendsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsOmsEJB.jar PowerOfAttorneyBean RbsOmsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsOmsEJB.jar OmsDataBean RbsOmsEJB.jar,META-INF/ejb-jar.xml "" "" "" ][ RbsCouponEJB.jar CouponControllerBean RbsCouponEJB.jar,META-INF/ejb-jar.xml "" "" "" ]] -MapModulesToServers [[ CommonCAEJB.jar CommonCAEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ CommonCIFEJB.jar CommonCIFEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ FrameworkEJB FrameworkEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsCAEJB.jar RbsCAEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsDdmsEJB.jar RbsDdmsEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsMiscEJB.jar RbsMiscEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsGLEJB.jar RbsGLEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ CommonTCEJB.jar CommonTCEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsBaEJB.jar RbsBaEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsSTCEJB.jar RbsSTCEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ BricEJB.jar BricEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsCashEJB.jar RbsCashEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsBVEJB.jar RbsBVEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsChequesEJB.jar RbsChequesEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsDraftEJB.jar RbsDraftEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsEREJB.jar RbsEREJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsPaymentsEJB.jar RbsPaymentsEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsLPEJB.jar RbsLPEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsMudarabahEJB.jar RbsMudarabahEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsLoanEJB.jar RbsLoanEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsBillsEJB.jar RbsBillsEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsTCEJB.jar RbsTCEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsCrossServicesEJB RbsCrossServicesEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsCardManagementEJB.jar RbsCardManagementEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsSafeBoxEJB.jar RbsSafeBoxEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsClaimsEJB.jar RbsClaimsEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsShareDividendsEJB.jar RbsShareDividendsEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsOmsEJB.jar RbsOmsEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsCouponEJB.jar RbsCouponEJB.jar,META-INF/ejb-jar.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ][ RbsWeb RbsWeb.war,WEB-INF/web.xml WebSphere:cell='+cellName+',node='+nodeName+',server=server1+WebSphere:cell='+cellName+',node='+nodeName+',server=webserver1 ]] -MapSharedLibForMod [[ RbsEAR META-INF/application.xml RBS_LIBRARY ]]]' )
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')    
#endDef
###############################Application UPDATE-End##############################
###############################Application Start-Begin##############################
def START_APP():
				#Start the app 
				apps = AdminApp.list().splitlines(); 
				theApp = ""    
				for iApp in apps:
								if (str(iApp) == tmp.strAppToInstallTrim):
        								theApp = iApp;
												#serverstatus = AdminControl.completeObjectName('type=Application,name=theApp,*')
        								status = isApplicationRunning(theApp, serverName, nodeName)
        								#print status
        								print "#########################Starting Application############################"   
        								print "###Starting App: ", theApp
        								if (status == 0):
																appManager = AdminControl.queryNames('cell='+cellName+',node='+nodeName+',type=ApplicationManager,process='+serverName+',*')
																AdminControl.invoke(appManager, 'startApplication', theApp)
																log_it('Application in stopped state and started successfuly!')
												#endIF
        								if (status == 1):
																log_it('Application already in running state!')
												#endIF
				log_it ('OK')
#endDef
###############################Application Start-End##############################
###############################Application Stop-Begin##############################
def STOP_APP():
				#Stop the app 
				apps = AdminApp.list().splitlines(); 
				theApp = ""    
				for iApp in apps:
								if (str(iApp) == tmp.strAppToInstallTrim):
        								theApp = iApp;
												#serverstatus = AdminControl.completeObjectName('type=Application,name=theApp,*')
        								status = isApplicationRunning(theApp, serverName, nodeName)
        								print "#########################Stoping Application############################"   
        								#print status
        								print "###Stopping App: ", theApp
        								if (status == 1):
																appManager = AdminControl.queryNames('cell='+cellName+',node='+nodeName+',type=ApplicationManager,process='+serverName+',*')
																AdminControl.invoke(appManager, 'stopApplication', theApp)
																log_it('Application in runing state and stopped successfuly!')
												#endIF
        								if (status == 0):
																log_it('Application already in stopped state!')
												#endIF
				log_it ('OK')
#endDef
###############################Application Stop-End##############################
###############################Map Module to WebServer-Begin##############################
def MAP_WEBSERVER():
				print "#########################Mapping Web Module to WebServer############################"
				string = AdminApp.listModules(''+eval("tmp.strAppToInstallTrim")+'', '-server')
				#string1 = string.replace('#', ' ')
				string = string.split('#')
				string1 = string[1].split('+')
				mapto='[[ '+string1[0]+' '+string1[0]+',WEB-INF/web.xml WebSphere:cell='+cellName+',node='+nodeName+',server='+serverName+'+WebSphere:cell='+cellName+',node='+nodeName+',server='+web_serverName+' ]]'
				AdminApp.edit(''+eval("tmp.strAppToInstallTrim")+'', '[ -MapModulesToServers '+mapto+']' ) 
				log_it('Application Mapped to Webserver successfuly!')
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK')
#endDef
###############################Map Module to WebServer-End################################
######################Application Shared Library Mapping-Begin########################
def SHAREDLIB_MAP():
				print "#########################Mapping Shared Library############################"
				print "###Mapping Shared Library for the App: ", tmp.strAppToInstallTrim
				AdminApp.edit(''+eval("tmp.strAppToInstallTrim")+'', '[ -MapSharedLibForMod [[ "'+eval("tmp.strAppToInstallTrim")+'" META-INF/application.xml "'+eval("prop.shrd_Lib")+'"]]]' )
				log_it ('Saving Configuration ...')
				AdminConfig.save( )
				log_it ('OK') 
#endDef
######################Application Shared Library Mapping-End########################

##########################################################################################
##########################################################################################
#																				MAIN PROGRAM																		 #
##########################################################################################
##########################################################################################
#Uncomment below functions which you want to do the configuration changes, Keep it 
#commented those functions are required 
##########################################################################################
import sys
import socket
import re
import string
import time
import prop
import tmp
#######################Define the Variable#############################################    
cellName = AdminControl.getCell( )
nodeName = AdminControl.getNode( )
hostName = socket.gethostname( )
serverName = prop.server_Name
web_serverName = prop.web_serverName
server_Id = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:"+serverName+"/" )
WebContainerId = AdminConfig.list("WebContainer", server_Id )
jvmId = AdminConfig.getid("/Node:"+nodeName+"/Server:"+serverName+"/JavaProcessDef:/JavaVirtualMachine:/" )
########################################END#############################################
###########################Define Log_it-Begin#########################################
def log_it(msg):
    dts = time.strftime('%Y-%m-%d %H:%M:%S')
    print "./jython/" + file_Name + ":" + dts + " " ,msg
#endDef
##############################Log_it-End########################################
#######################################################################################
print '-------------------------------------------------------------------'
print "\tRetrived parameter from Installed Websphere :\n"
print "\tCell: "+cellName+"\n\tNode: "+nodeName+"\n\tServer: "+serverName
print '-------------------------------------------------------------------'
#######################################################################################

#numberOfArgs = len(sys.argv)
#if numberOfArgs < 2:
 #   print "Usage: deploy_app.py {file-absolute-path} {context-root}"
#else:
    #Get the absolute path of the WAR file and replace \ with / 
filePath1 = prop.ear_Path
#filePath1 = filePath1.replace('\\', '/')  ####Usefull for windows deployment
contextRoot = ""
####################################Function Call##################################
#STOP_APP() ===> Stopping already Installed Applications
#UNINSTALL_APP()===> Uninstall existing application
#UPDATE_APP()===> Updating Application
#DEPLOY_APP()===> EAR file Deployment funtion, refer to "deploy_app.prop" for required 
#									Parameters for application deployment
#SHAREDLIB_MAP()===> Shared Library reference mapping as defined in property file
#START_APP()===> Starting Application after the deployment
#MAP_WEBSERVER(===> Mapping application module to webserver target(will work for the EAR 
#							 file has only one "WAR" module) for multiple "WAR" mapping please comment
#							 below "MAP_WEBSERVER()" function and map it to webserver manually after deployment
####################################################################################
STOP_APP()
#UNINSTALL_APP()
#DEPLOY_APP()
UPDATE_APP()
#SHAREDLIB_MAP()
#MAP_WEBSERVER()
START_APP()
