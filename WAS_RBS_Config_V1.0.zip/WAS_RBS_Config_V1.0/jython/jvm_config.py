######################################################################################
#
# Script  : jvm_config.py
#
######################################################################################
##
#History
# 1.0 initial script created by Aloysius Pious
######################################################################################
Version="1.0"
file_Name="jvm_config.py"
######################################################################################

###########################Define Funtion-Begin#########################################
def log_it(msg):
    dts = time.strftime('%Y-%m-%d %H:%M:%S')
    print "./jython/" + file_Name + ":" + dts + " " ,msg
#endDef
##############################Define Funtion-End########################################

##########################WebContainer Custom Property-Begin############################
def WEBCONTAINER_CUSTOM_PROPERTY():
			log_it ('Setting Webcontainer Custom property Configuration ...')
			AdminConfig.create('Property', ''+WebContainerId+'', '[[validationExpression ""] [name "prependSlashToResource"] [description ""] [value "'+prop.prependSlashToResource+'"] [required "false"]]') 
			log_it ('Saving Configuration ...')
			AdminConfig.save( )
			log_it ('OK')
#endDef
#############################WebContainer Custom Property-End###########################
###############################WebContainer ThreadPool-Begin############################
def WEBCONTAINER_THREADPOOL():
			for threadPool in AdminConfig.list("ThreadPool", server_Id ).splitlines():
									if(re.search("WebContainer", threadPool)):
													log_it ('Setting Webcontainer ThreadPool for Transport Chain ...')
													AdminConfig.modify(threadPool, '[[maximumSize "'+prop.thread_Max+'"] [name "WebContainer"] [minimumSize "'+prop.thread_Min+'"] [inactivityTimeout "'+prop.inact_Tmot+'"] [description "A thread pool enables components of the server to reuse threads"] [isGrowable "false"]]') 
													log_it ('Saving Configuration ...')
													AdminConfig.save( )
													log_it ('OK')
#endDef	
###############################WebContainer ThreadPool-End##############################
##################################JVM Heap Settings-Begin###############################
def JVM_HEAP():
			log_it ('Setting JVM Minimum and Maximum Heap Size ...')
			AdminTask.setJVMProperties('[-serverName '+serverName+' -nodeName '+nodeName+' -initialHeapSize '+prop.min_heap+' -maximumHeapSize '+prop.max_heap+' ]')
			log_it ('Saving Configuration ...')
			AdminConfig.save( )
			log_it ('OK')
#endDef
##################################JVM Heap Settings-End###################################
###############################WebSphere Variable-Begin###################################
def WEBSPHERE_VAR():
			for b in range(tmp.no_of_var):
#-----------------------------------------Node Scope Variable------------------------------------
							if (eval("prop.VAR_scope"+str(b)) == "NODE"):  				
											var_node = AdminConfig.getid('/Cell:'+cellName+'/Node:'+nodeName+'/VariableMap:/')
											variables = AdminConfig.list("VariableSubstitutionEntry", var_node).splitlines()
											for variable in variables[:]:
															vname = AdminConfig.showAttribute(variable, "symbolicName")
															if (vname == eval("prop.VAR_variable"+str(b))):
																							print "Removing old variable " + vname + " from variables.xml..."
																							AdminConfig.remove(variable)
																							log_it ('Saving Configuration ...')
																							AdminConfig.save( )
																							log_it ('OK')
											#endFor
											print "### Creating Websphere Variable on NODE scope for",eval("prop.VAR_variable"+ str(b))
											AdminConfig.create('VariableSubstitutionEntry', '(cells/'+cellName+'/nodes/'+nodeName+'|variables.xml#VariableMap_1)', '[[symbolicName "'+eval("prop.VAR_variable"+str(b))+'"] [description "'+eval("prop.VAR_desc"+str(b))+'"] [value "'+eval("prop.VAR_value"+str(b))+'"]]') 
											log_it ('Saving Configuration ...')
											AdminConfig.save( )
											log_it ('OK')																							
#-----------------------------------------Server Scope Variable------------------------------------
							else:
											var_srv = AdminConfig.getid('/Cell:'+cellName+'/Node:'+nodeName+'/Server:'+serverName+'/VariableMap:/')
											variables = AdminConfig.list("VariableSubstitutionEntry", var_srv).splitlines()
											for variable in variables[:]:
															vname = AdminConfig.showAttribute(variable, "symbolicName")
															if (vname == eval("prop.VAR_variable"+str(b))):
																							print "Removing old variable " + vname + " from variables.xml..."
																							AdminConfig.remove(variable)
																							log_it ('Saving Configuration ...')
																							AdminConfig.save( )
																							log_it ('OK')
											#endFor
											print "### Creating Websphere Variable on SERVER scope for",eval("prop.VAR_variable"+ str(b))
											AdminConfig.create('VariableSubstitutionEntry', '(cells/'+cellName+'/nodes/'+nodeName+'/servers/'+serverName+'|variables.xml#VariableMap_1)', '[[symbolicName "'+eval("prop.VAR_variable"+str(b))+'"] [description "'+eval("prop.VAR_desc"+str(b))+'"] [value "'+eval("prop.VAR_value"+str(b))+'"]]') 
											log_it ('Saving Configuration ...')
											AdminConfig.save( )
											log_it ('OK')																			
			b=b+1
			#endFor
#endDef
###############################WebSphere Variable-End###################################

###############################Shared Library Setting-Begin##############################
def SHARED_LIB():
			log_it ('Creating Shared Library Variable ...')
			for a in range(tmp.no_of_shlib):
											print "### Creating Shared Library Variable for",eval("prop.SHLIB_name"+ str(a))
											AdminConfig.create('Library',server_Id, '[[nativePath "'+eval("prop.SHLIB_native_path"+str(a))+'"] [name "'+eval("prop.SHLIB_name"+str(a))+'"] [isolatedClassLoader "'+eval("prop.SHLIB_iso_clsload"+str(a))+'"] [description "'+eval("prop.SHLIB_desc"+str(a))+'"] [classPath "'+eval("prop.SHLIB_class_path"+str(a))+'"]]') 
											log_it ('Saving Configuration ...')
											AdminConfig.save( )
											log_it ('OK')
			a=a+1
			#endFor
#endDef
###############################Shared Library Setting-End#################################
##########################################################################################
#																				MAIN PROGRAM																		 #
##########################################################################################
##########################################################################################
import sys
import socket
import re
import string
import time
import prop
import tmp
#######################Define the Variable#############################################    
cellName = AdminControl.getCell( )
nodeName = AdminControl.getNode( )
hostName = socket.gethostname( )
serverName = prop.server_Name
server_Id = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:"+serverName+"/" )
WebContainerId = AdminConfig.list("WebContainer", server_Id )
jvmId = AdminConfig.getid("/Node:"+nodeName+"/Server:"+serverName+"/JavaProcessDef:/JavaVirtualMachine:/" )
########################################END#############################################
#######################################################################################
print '-------------------------------------------------------------------'
print "\tRetrived parameter from Installed Websphere :\n"
print "\tCell: "+cellName+"\n\tNode: "+nodeName+"\n\tServer: "+serverName
print '-------------------------------------------------------------------'
#######################################################################################
##########################################################################################
#																			FUNCTION CALL
##########################################################################################
#Uncomment below functions which you want to do the configuration changes, Keep it 
#commented those functions are required 
#WEBCONTAINER_CUSTOM_PROPERTY()===> to set "prependSlashToResource=true"
#WEBCONTAINER_THREADPOOL()===> set Thread pool size as defined in property file
#JVM_HEAP()===> set JVM heap size as defined in property file
#SHARED_LIB()===> create Shared Library variable as defined in property file
#WEBSPHERE_VAR()===> create Websphere variable as defined in property file
##########################################################################################	

WEBCONTAINER_THREADPOOL()
#WEBCONTAINER_CUSTOM_PROPERTY()
JVM_HEAP()
#SHARED_LIB()
WEBSPHERE_VAR()