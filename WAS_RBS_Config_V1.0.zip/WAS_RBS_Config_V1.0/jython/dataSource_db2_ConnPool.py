#! /usr/bin/ksh
# ####################################################################################
#
# Script  : dataSource_db2_ConnPool.sh
#
# Description: DB2 connection pool DataSource creation script for Websphere
# Author : Aloysius Pious
# Email  : aloysiuspious@alrajhibank.com.sa
#######################################################################################
#History
# 1.0 initial script created by Aloysius Pious
# 1.1 added script for container managed authentication modification
# 1.2 added script for custom property modification
#######################################################################################
Version="1.2"
Description="DB2 connection pool DataSource creation script for Websphere"
file_Name="dataSource_db2_ConnPool.py"
####################################################################################
def log_it(msg):
    dts = time.strftime('%Y-%m-%d %H:%M:%S')
    print "./jython/" + file_Name + ":" + dts + " " ,msg
#endDef
####################Create JDBCProvider - DB2/Oracle-Begin###############################
def JDBC_PROVIDER():
		print "################################DB2 JDBCProvider Creation####################################"
		log_it ('Creating JDBCProvider ...')
		a=1
		for a in range(tmp.no_of_jdbc_prov):
										print "### Creating Connection Pool JDBC Providers for-->",eval("prop.JDBCProvider_type"+str(a))
										AdminTask.createJDBCProvider('[-scope Node='+nodeName+',Server='+prop.jvm_Id+' -databaseType "'+eval("prop.db_type"+str(a))+'" -providerType "'+eval("prop.JDBCProvider_type"+str(a))+'" -implementationType "Connection pool data source" -name "'+eval("prop.JDBCProvider_name"+str(a))+'" -description "'+eval("prop.JDBCProvider_desc"+str(a))+'" -classpath "'+eval("prop.class_path"+str(a))+'" -nativePath "'+eval("prop.native_path"+str(a))+'" ]')
										log_it ('Saving Configuration ...')
										AdminConfig.save( )
		a=a+1
		#endFor
		log_it ('Saving Configuration ...')
		AdminConfig.save( )
		log_it ('OK')
#endDef
####################Create JDBCProvider - DB2/Oracle-End###############################
####################Create J2C Authentication data-Begin###############################
def J2CC_AUTH_ALIAS():
		print "##############################J2CC Authentication data Creation##############################"
		log_it ('Creating J2C Authentication Data ...')
		a = 1
		for a in range(tmp.no_auth_alias):
										print "### Creating J2C authentication Data for-->",eval("prop.auth_alias"+ str(a))
										AdminTask.createAuthDataEntry('[-alias '+eval("prop.auth_alias"+str(a))+' -user '+eval("prop.db_user"+str(a))+' -password '+eval("prop.db_pwd"+str(a))+' -description "'+eval("prop.db_des"+str(a))+'" ]') 
		a=a+1
		#endFor
		log_it ('Saving Configuration ...')
		AdminConfig.save( )
		log_it ('OK')
#endDef
		####################Create J2C Authentication data-End###############################
		####################Create DB2 DataSource -Begin###############################
def DATA_SOURCES():
		print "##################################DataSource Creation########################################"
		log_it ('Creating DB2 Datasources ...')
		newDs = AdminConfig.getid('/Cell:' + cellName +'/Node/'+nodeName+'/Server/'+prop.jvm_Id+'/JDBCProvider:' + "DB2 Using IBM JCC Driver" +'/')
		a = 1
		for a in range(tmp.no_of_ds):
										print "### Creating DB2 DataSource for-->",eval("prop.ds_name"+ str(a))
										AdminTask.createDatasource('"'+newDs+'"', '[-name "'+eval("prop.ds_name"+str(a))+'" -description "'+eval("prop.db_desc"+str(a))+'" -jndiName '+eval("prop.jndi_name"+str(a))+' -dataStoreHelperClassName '+eval("prop.ds_helper"+str(a))+' -containerManagedPersistence '+eval("prop.container_mngd_persistence"+str(a))+' -componentManagedAuthenticationAlias '+nodeName+'/'+eval("prop.map_comp_auth"+str(a))+' -configureResourceProperties [[databaseName java.lang.String '+eval("prop.db_name"+str(a))+'] [driverType java.lang.Integer 4] [serverName java.lang.String '+eval("prop.db_host"+str(a))+'] [portNumber java.lang.Integer '+eval("prop.db_port"+str(a))+']]]')
		a=a+1
		#endFor
		log_it ('Saving Configuration ...')
		AdminConfig.save( )
		log_it ('OK')
#endDef
####################Create DB2 DataSource -End###############################
##################################Connection Poool Parameter Modification-Begin#####################
def DATA_SOURCES_CONNECTION_POOL():
		print "########################DataSource Connection Pool Configuration#############################"
		log_it ('Creating Connection Pool parameters for Datasources ...')
		a = 1
		for a in range(tmp.no_of_ds):
										print "### Modifying Connection Pool Parameter for-->",eval("prop.jndi_name"+ str(a))
										for dataSource in AdminConfig.list('DataSource').splitlines():
       										 	jndi= AdminConfig.showAttribute(dataSource, 'jndiName')
       					 						if(re.search(eval("prop.jndi_name"+ str(a)), jndi)):
       														connPool=AdminConfig.showAttribute(dataSource, 'connectionPool')
       														AdminConfig.modify(connPool, '[[connectionTimeout "'+eval("prop.conn_tmout"+str(a))+'"] [maxConnections "'+eval("prop.max_conn"+str(a))+'"] [unusedTimeout "'+eval("prop.unusd_tmout"+str(a))+'"] [minConnections "'+eval("prop.min_conn"+str(a))+'"] [agedTimeout "'+eval("prop.agd_tmout"+str(a))+'"] [purgePolicy "'+eval("prop.purg_polcy"+str(a))+'"] [reapTime "'+eval("prop.rp_time"+str(a))+'"]]')				
		a = a + 1
		#endFor
		log_it ('Saving Configuration ...')
		AdminConfig.save( )
		log_it ('OK')
#endDef
###########################Connection Poool Parameter Modification-End#######################
###########################Custom properties for Datasources-Begin#######################
def DATA_SOURCES_CUSTOM_PROP():
		print "########################DataSource Custom property Configuration#############################"
		log_it ('Creating Custom properties for Datasources ...')
		a = 1
		for a in range(tmp.no_of_ds):
										p="ds_name"+str(a)
										s=eval("tmp."+p+"_custom_property")
										scopes = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:"+serverName+"/" ).splitlines()
										datasources = AdminConfig.list("DataSource", scopes[0]).splitlines()
										dss=eval("prop.ds_name"+str(a))
										for b in range(s):
																		custom_property="_custom_property"+str(b)
																		custom_value="_custom_value"+str(b)	
																		custom_type="_custom_type"+str(b)			
																		custom_desc="_custom_desc"+str(b)
																		custom_required="_custom_required"+str(b)
																		###########
																		custom_property=p+custom_property
																		custom_value=p+custom_value
																		custom_type=p+custom_type
																		custom_desc=p+custom_desc
																		custom_required=p+custom_required
																		###########
																		custom_property=eval("prop."+custom_property)
																		custom_value=eval("prop."+custom_value)
																		custom_type=eval("prop."+custom_type)
																		custom_desc=eval("prop."+custom_desc)
																		custom_required=eval("prop."+custom_required)
																		###################
																		for datasource in datasources :
																										if AdminConfig.showAttribute(datasource, "name") == dss :
																														propertySet = AdminConfig.list("J2EEResourcePropertySet", datasource).splitlines()
																														customProp = [["name", custom_property], ["value", custom_value], ["type", custom_type], ["description", custom_desc], ["required", custom_required]]
																														for property in AdminConfig.list("J2EEResourceProperty", propertySet[0]).splitlines() :
																																						AdminConfig.showAttribute(property, "name")
																																						if AdminConfig.showAttribute(property, "name") == custom_property :
																																										log_it ('Custom property exist and modifying it with new value...')
																																										AdminConfig.remove(property)
																																										print "###",custom_property,"as",custom_value,"for-->", dss
																																										#log_it ('Creating Custom property with new value ...')
																																										AdminConfig.create("J2EEResourceProperty", propertySet[0], customProp)
																																						#endIf
																														#endFor																												
																										#endIf
																			#endFor

										#b=b+1
										#endFor
		#endFor
		log_it ('Saving Configuration ...')
		AdminConfig.save( )
		log_it ('OK')
#endDef

###########################Custom properties for Datasources-End#######################
###########################Container-managed authentication alias for Datasources-Begin#######################
def CONT_AUTH_ALIAS():
		print "#####################Container-managed authentication alias for Datasources########################"
		log_it ('Creating Container-managed authentication alias  ...')
		for a in range(tmp.no_of_ds):
										print "### Creating Container-managed authentication alias  for-->",eval("prop.ds_name"+ str(a))
										techsamp=AdminConfig.getid('/DataSource:'+eval("prop.ds_name"+ str(a))+'/')
										AdminConfig.create('MappingModule',techsamp, '[[authDataAlias '+nodeName+'/'+eval("prop.map_cont_auth"+str(a))+'] [mappingConfigAlias ""]]')  
		log_it ('Saving Configuration ...')
		AdminConfig.save( )
		log_it ('OK')
#endDef
###########################Container-managed authentication alias for Datasources-End#######################
##########################################################################################
#																				MAIN PROGRAM																		 #
##########################################################################################
##########################################################################################
import sys
import socket
import re
import string
import time
import prop
import tmp
import time
#######################Define the Variable#############################################   
cellName = AdminControl.getCell( )
nodeName = AdminControl.getNode( )
hostName = socket.gethostname( )
serverName = prop.jvm_Id
########################################END##################################################

print "######################################################################################"
print "###",Description,"version:",Version
#######################################################################################
print '-------------------------------------------------------------------'
print "\tRetrived parameter from Installed Websphere :\n"
print "\tCell: "+cellName+"\n\tNode: "+nodeName+"\n\tServer: "+serverName
print '-------------------------------------------------------------------'
#######################################################################################
##########################################################################################
#																			FUNCTION CALL
##########################################################################################
#Uncomment below functions which you want to do the configuration changes, Keep it 
#commented those functions are required 
##########################################################################################	
JDBC_PROVIDER()
J2CC_AUTH_ALIAS()
DATA_SOURCES()
CONT_AUTH_ALIAS()
DATA_SOURCES_CONNECTION_POOL()
DATA_SOURCES_CUSTOM_PROP()