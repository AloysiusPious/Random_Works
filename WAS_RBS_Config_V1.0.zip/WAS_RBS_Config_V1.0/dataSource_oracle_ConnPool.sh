  #! /usr/bin/ksh
# #################################################################################
#
# Script  : was_otg_config.sh
#
# Description:
##################################################################################
#History
# 1.0 initial script created by Aloysius Pious
###################################################################################
Version="1.2"
############### ###################################################################
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}
export DISPLAY=""
DATE=`date "+%d%m%Y"`
Present_Dir=`pwd`
PROFILE_NAME=AppSrv01
WAS_INSTALL_ROOT=/usr/IBM
WAS_INST_HOME=${WAS_INSTALL_ROOT}/WebSphere/AppServer
PROFILE_HOME=${WAS_INST_HOME}/profiles/${PROFILE_NAME}
if [ ! -d ${PROFILE_HOME} ] ; then
   log_it "Failed... ${PROFILE_HOME} not found"
exit 0
fi
#######################################################################################
############################Processing Property Files###################################
clear
print "\n\n"
print "######### Websphere Application Server Configutaion for Specific Applications#########"
echo "---------------------------------------------------------------------------------"
log_it "Start executing the Script ..."
>${Present_Dir}/jython/tmp.py
>${Present_Dir}/jython/prop.py
grep "^[^#;]" ${Present_Dir}/props/was_config.prop  > ${Present_Dir}/prop.py
echo "###########Number of Datasource needed################" >> ${Present_Dir}/tmp.py
no_of_ds=`grep ds_name ${Present_Dir}/prop.py | grep "^[^#;]"| wc -l`
no_of_ds=`echo ${no_of_ds} | sed -e 's/^ *//' -e 's/ *$//'`   ##Remove blank space from variable
echo "no_of_ds=${no_of_ds}" >> ${Present_Dir}/tmp.py
echo "###########Number of JDBC Provider needed################" >> ${Present_Dir}/tmp.py
no_of_jdbc_prov=`grep db_type ${Present_Dir}/prop.py | grep "^[^#;]" |wc -l`
no_of_jdbc_prov=`echo ${no_of_jdbc_prov} | sed -e 's/^ *//' -e 's/ *$//'`   ##Remove blank space from variable
echo "no_of_jdbc_prov=${no_of_jdbc_prov}" >> ${Present_Dir}/tmp.py
echo "###########Number of JDBC Provider needed################" >>${Present_Dir}/tmp.py
no_auth_alias=`grep auth_alias ${Present_Dir}/prop.py | grep "^[^#;]" |wc -l`
no_auth_alias=`echo ${no_auth_alias} | sed -e 's/^ *//' -e 's/ *$//'`   ##Remove blank space from variable
echo "no_auth_alias=${no_auth_alias}" >> ${Present_Dir}/tmp.py

########################JVM Restart Function###########################################
restart_JVM()
{
log_it "Restarting the WebSphere process..."
${PROFILE_HOME}/bin/stopServer.sh server1
${PROFILE_HOME}/bin/startServer.sh server1
log_it "OK"
}
######################################################################################
log_it "Running Jython scripts to change the configuration..."
${PROFILE_HOME}/bin/wsadmin.sh -lang jython -f ${Present_Dir}/jython/dataSource_db2_ConnPool.py
log_it "OK"

######################################################################################
rm_TMP()
{
rm ${Present_Dir}/prop.py
rm ${Present_Dir}/tmp.py
rm ${Present_Dir}/*.class
}
rm_TMP