#! /usr/bin/ksh
# #################################################################################
#
# Script  : jvm_config.sh
#
# Description:
##################################################################################
#History
# 1.0 initial script created by Aloysius Pious
###################################################################################
Version="1.2"
###################################################################################
######################Reading property File for Profile Name#######################
. ./props/jvm_config.prop
###################################################################################


########################JVM Restart Function###########################################
restart_JVM()
{
log_it "Restarting the WebSphere process..."
${PROFILE_HOME}/bin/stopServer.sh server1
${PROFILE_HOME}/bin/startServer.sh server1
log_it "OK"
}
######################################################################################
wsadmin_EXE()
{
log_it "Running Jython scripts to change the configuration..."
${PROFILE_HOME}/bin/wsadmin.sh -lang jython -f ${Present_Dir}/jython/jvm_config.py | tee -a ${LOG}
log_it "Done."
}
######################################################################################
rm_TMP()
{
rm ${Present_Dir}/prop.py
rm ${Present_Dir}/tmp.py
rm ${Present_Dir}/*.class
}


##############################Logging Funtion-Begin#################################
log_it()
{
   echo "${0}:$(date +%Y"-"%m"-"%d" "%X)  ${1}" | tee -a ${LOG}
}
##############################Logging Funtion-End####################################

##########################################################################################
##########################################################################################
#																				MAIN PROGRAM																		 #
##########################################################################################
##########################################################################################
export DISPLAY=""
NOW=$(date +"%F")
NOWT=$(date +"%T")
LOG="./logs/${NOW}-${NOWT}_jvm_config.log"
DATE=`date "+%d%m%Y"`
Present_Dir=`pwd`
PROFILE_NAME=${PROFILE_NAME}
WAS_INSTALL_ROOT=/usr/IBM
WAS_INST_HOME=${WAS_INSTALL_ROOT}/WebSphere/AppServer
PROFILE_HOME=${WAS_INST_HOME}/profiles/${PROFILE_NAME}

if [ ! -d ${PROFILE_HOME} ] ; then
   log_it "Failed... ${PROFILE_HOME} not found"
exit 0
fi
#######################################################################################
#########Keep only latest 3 log files and delete others from current directory#######
count=`find . -type f -name "*jvm_config.log" | wc -l`
if [ $count -gt 3 ]
then 
    log_it "Deleting old logs files ..."
		rm `ls -t ./logs/*jvm_config.log | awk 'NR>3'`
		log_it "OK"
else
		log_it "No old log files found ..."
		log_it "OK"
fi 
#######################################################################################
############################Processing Property Files###################################
print "######### Websphere Application Server Configutaion for Specific Applications#########"
echo "---------------------------------------------------------------------------------"
log_it "Start executing the Script ..."
>${Present_Dir}/tmp.py
>${Present_Dir}/prop.py
grep "^[^#;]" ${Present_Dir}/props/jvm_config.prop  > ${Present_Dir}/prop.py
echo "###########Number of Datasource needed################" >> ${Present_Dir}/tmp.py
no_of_ds=`grep ds_name ${Present_Dir}/prop.py | grep "^[^#;]"| wc -l`
no_of_ds=`echo ${no_of_ds} | sed -e 's/^ *//' -e 's/ *$//'`   ##Remove blank space from variable
echo "no_of_ds=${no_of_ds}" >> ${Present_Dir}/tmp.py
echo "###########Number of JDBC Provider needed################" >> ${Present_Dir}/tmp.py
no_of_jdbc_prov=`grep db_type ${Present_Dir}/prop.py | grep "^[^#;]" |wc -l`
no_of_jdbc_prov=`echo ${no_of_jdbc_prov} | sed -e 's/^ *//' -e 's/ *$//'`   ##Remove blank space from variable
echo "no_of_jdbc_prov=${no_of_jdbc_prov}" >> ${Present_Dir}/tmp.py
echo "###########Number of JDBC Provider needed################" >>${Present_Dir}/tmp.py
no_auth_alias=`grep auth_alias ${Present_Dir}/prop.py | grep "^[^#;]" |wc -l`
no_auth_alias=`echo ${no_auth_alias} | sed -e 's/^ *//' -e 's/ *$//'`   ##Remove blank space from variable
echo "no_auth_alias=${no_auth_alias}" >> ${Present_Dir}/tmp.py
echo "###########Number of Shared Lib needed################" >>${Present_Dir}/tmp.py
no_of_shlib=`grep SHLIB_name ${Present_Dir}/prop.py | grep "^[^#;]"| wc -l`
no_of_shlib=`echo ${no_of_shlib} | sed -e 's/^ *//' -e 's/ *$//'`   ##Remove blank space from variable
echo "no_of_shlib=${no_of_shlib}" >> ${Present_Dir}/tmp.py
echo "###########Number of Variable needed################" >>${Present_Dir}/tmp.py
no_of_var=`grep VAR_desc ${Present_Dir}/prop.py | grep "^[^#;]"| wc -l`
no_of_var=`echo ${no_of_var} | sed -e 's/^ *//' -e 's/ *$//'`   ##Remove blank space from variable
echo "no_of_var=${no_of_var}" >> ${Present_Dir}/tmp.py
####################################Function Call##################################
wsadmin_EXE
rm_TMP
#restart_JVM
